import React from "react";
import Image from "next/image";
import Banner from "../../../public/gallery/background.jpeg";
import { Loader } from "../../common/Loader";

const HeroAbout = ({ data }) => {
  if (!data) return <Loader />;
  const tmp = data;
  return (
    <div class="relative pt-48 pb-12 bg-black sm:pb-16 lg:pb-32 2xl:pb-56">
      <div class="absolute inset-0">
        <Image
          class="object-cover w-full h-full"
          src={Banner}
          width={2000}
          height={800}
          alt=""
        />
      </div>

      <div className="max-w-screen-xl mx-auto grid grid-cols-1 lg:grid-cols-5 pb-16 pt-24 ">
        <div className="flex justify-center items-center col-span-3">
          <div className="mx-5 lg:ml-20 text-center lg:text-left z-30 ">
            <h1 className="text-2xl lg:text-5xl text-[#211A53] py-5 font-semibold">
              {tmp.title}
            </h1>
            <p className="text-sm text-left lg:text-base">{tmp.subtitle}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroAbout;
