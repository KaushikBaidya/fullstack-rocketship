const mysqlConfig = {
  host: "localhost",
  // database: "rockmhvf_rocketship",
  // user: "rockmhvf_admin",
  // password: "Kgi[0v726uQb",
  //------------------------
  user: "root",
  database: "rocketship",
  password: "",
  //------------
  // user: "rockmhvf_user",
  // database: "rockmhvf_test",
  // password: "Il#Q?FAse6HT",
};

export default mysqlConfig;
