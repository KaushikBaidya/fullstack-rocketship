"use strict";
(() => {
var exports = {};
exports.id = 8623;
exports.ids = [8623];
exports.modules = {

/***/ 518:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Banner = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "bg-white pb-20",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "items-center py-10 lg:py-28 px-5",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "xl:max-w-3xl mx-auto ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-[#221a55] text-2xl lg:text-4xl font-bold text-center",
                    children: "Securing college admissions is daunting. Let us simplify it for you."
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Banner);


/***/ }),

/***/ 1548:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Connect = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "bg-white my-10",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-sbanner",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-[#221a55dc] text-white items-center backdrop-blur-none gap-y-3 px-10 py-20 mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "xl:max-w-4xl mx-auto flex flex-col md:flex-row justify-around gap-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-white lg:w-3/4 text-center md:text-left",
                            children: "On the search for a new career or building a college list?"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/contactus",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "px-10 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                    children: "Contact Us"
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Connect);


/***/ }),

/***/ 4706:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_Loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8652);




const HeroAbout = ({ data  })=>{
    if (!data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Loader__WEBPACK_IMPORTED_MODULE_3__/* .Loader */ .a, {});
    const tmp = data;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "max-w-screen-2xl mx-auto overflow-hidden bg-aboutBg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "max-w-screen-xl mx-auto grid grid-cols-1 lg:grid-cols-5 pb-16 pt-24 ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center items-center col-span-3",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mx-5 lg:ml-20 text-center lg:text-left z-30 ",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-2xl lg:text-5xl text-[#211A53] py-5 font-semibold",
                            children: tmp.title
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-sm text-left lg:text-base font-semibold",
                            children: tmp.subtitle
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroAbout);


/***/ }),

/***/ 9011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ about_HowWeWork)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/gallery/y.png
/* harmony default export */ const y = ({"src":"/_next/static/media/y.d59776bd.png","height":775,"width":450,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAApUlEQVR42mMAgf///zOemLd0xoH5y3fcXrdJiAEEzm3aGvpg3cb/19dv/n921fpyhj2bN/GHz5sr9nLn7rO3tu28yzBtHi/DyVXLuUCqb2zbfe363gPTGGDg3Kr1ls/WbTiye+EisaWbNgoxnJq3WPfy6g2JjydNUernZ+BgAIGXOsYOTxkYxJ8zMFh81DEWZwABS3F/JS+TKH0902gZEL9dxY8RAAmQQ7S0cCD8AAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./components/client/about/HowWeWork.js




const HowWeWork = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "w-full",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "max-w-2xl mx-auto pb-5",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-[#221a55] text-4xl font-bold text-center",
                        children: "How it works"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "xl:max-w-screen-xl grid grid-cols-1 lg:grid-cols-5 h-full pb-5 mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex justify-center items-center col-span-2 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "py-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-3/4 mx-auto ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: y,
                                        alt: "our work structure"
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex items-center justify-center mx-5 col-span-3",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "md:pr-2 md:py-6",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex relative pb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "h-full w-10 absolute inset-2 flex items-center justify-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "h-full w-1 bg-gray-200 pointer-events-none"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRocket1 bg-no-repeat"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-grow pl-4",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-normal text-base text-gray-900 mb-5",
                                                    children: "First, a Rocketship consultant will provide you free consultation to see if you are eligible to apply to an University in United States"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex relative pb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "h-full w-10 absolute inset-2 flex items-center justify-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "h-full w-1 bg-gray-200 pointer-events-none"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRocket2 bg-no-repeat"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-grow pl-4",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-normal text-base text-gray-900 mb-5",
                                                    children: "After you determined you want to work with us , you will fill out your profile. Then, based on your profile, the major you want study, and eligibility, Rocketship consultant will help come up with an university list. If you have you own list, we will give you a clear picture of your chances of getting an admitted to those colleges."
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex relative pb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "h-full w-10 absolute inset-2 flex items-center justify-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "h-full w-1 bg-gray-200 pointer-events-none"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRocket3 bg-no-repeat"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-grow pl-4",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-normal text-base text-gray-900 mb-5",
                                                    children: "Your test scores in IELTS, TOFL, or SAT qualify you to pursue a degree from top university in the United States. If you need help on these prep, we will match you with Test Preparation consultant"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex relative pb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "h-full w-10 absolute inset-2 flex items-center justify-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "h-full w-1 bg-gray-200 pointer-events-none"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRocket4 bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "text-white font-bold",
                                                    children: "4"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-grow pl-4",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-normal text-base text-gray-900 mb-5",
                                                    children: "When the application opens for your university, we will get you documents ready: transcripts, resume, extracurricular activities, and letters of recommendations."
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex relative pb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "h-full w-10 absolute inset-2 flex items-center justify-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "h-full w-1 bg-gray-200 pointer-events-none"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRocket5 bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "text-white font-bold",
                                                    children: "5"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-grow pl-4 pb-5",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-normal text-base text-gray-900 mb-5",
                                                    children: "A key part of the application is your Essays (Personal Statement) and often a supplemental essay. We will help you craft your essay and ensure your profile stands out to the admissions committee"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex relative pb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "h-full w-10 absolute inset-2 flex items-center justify-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "h-full w-1 bg-gray-200 pointer-events-none"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRocket6 bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "text-white font-bold",
                                                    children: "6"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-grow pl-4",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-normal text-base text-gray-900 mb-5",
                                                    children: "Rocketship Consultant will start by listing down all the possible scholarships a student can get based on his background and scores. Once the scholarships are identified, mentors at we will help the students with the application process, like documentation, essays, etc."
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex relative pb-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRocket7 bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "text-white font-bold",
                                                    children: "7"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-grow pl-4 pb-5",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-normal text-base text-gray-900 mb-5",
                                                    children: "Finally, after accepting the offer from the university of your choice, the next step is applying for the visa. We will help you with your visa document and conduct several mock interviews as well."
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const about_HowWeWork = (HowWeWork);


/***/ }),

/***/ 4198:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ about_OurTeam)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/team/rafsun.png
/* harmony default export */ const rafsun = ({"src":"/_next/static/media/rafsun.1e06b866.png","height":350,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AcXFwgDz+PwwtbOzmA/qzTMOJTcB/RgpzBEIBWcjGxPRAcC5sTD9AgTDyrq4DFgzCwD1+fgAyfspABMTE/QSDgo9Aaqno8giIyE3xaaf+zsnDgUsNi8A5fsU+9jt/wXPyMHJAbKhkPwYGRcD4N7hAArdwwA/S0AAtdr+AAMDBwDy8O38AYx1X/z6/wADDRYfABzqwQBETU4Ao83/AOXTvQD9DBj9AQAAEcgAGCI3AA4O+8eFWAUYGRgAoMLk+6+2ygUFAPPJATI+VDDO5+7DEQQBDH9rWAA5NTEAlJunALzP5fRPPTY8AQAnRgA1Ef4wy8jomIB+VDM0NDQBiZivzMO2nWgeOWDQUaZuj1gSpv0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/team/habib.png
/* harmony default export */ const habib = ({"src":"/_next/static/media/habib.63800035.png","height":350,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABCUlEQVR42h3Pv0rDQAAH4N8ludRgFUu1pRTs5OQSagVBnVzdXJ3FV3FzzODg4BM4OXXpJI3gEOiiDtKaO2MwJX+qudydxe8NPoKl19GdS6nlhVE84DxCr9vyTcu8BPBMJsMbt2bbo/ynrL8N75G+P6FxcoFuu5El8fzI0kp5pRB1rSrRrBFqOE2sECmKfFEnhuEZUqq9SpSwKKVqo4swfIHUmi7yAr9luW9VsiJKAZ3NLaz2D8GSArbtAFoim6ewtCzH01lyEEyY6G23aLXewTRMRPT1STutNd88Pd713f7gnDHuXF/dwnZsPI4DE7rKdnrtM4KlOHhwOWPe7IMPWMgR8dCPv9P/5h87oX95SGIbHgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/team/kaushik.png
/* harmony default export */ const kaushik = ({"src":"/_next/static/media/kaushik.58dcd8a3.png","height":350,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABA0lEQVR42mMAgU2+vprbgwIP7QkP+7U7JPjX1oCAg1v8/TXBkhtBkoGB71Z7eP73Y2D4X65l8n9LQMB/oKJ3m0GKtgQGHtzm4/N/UVzMz3WzZ/wvSEr4P8nG+ufOoKD/QAWHGLYGBf3a4ub2f2VJ+f/re3b/3zCl//8Mb5//OwICQSb9AivY5Ozyf3dr6/8ja9f/X9zZ+X9NqO//7X7+EAVbgkIObXe2+r88Ne/n4paG/4UxOf97s6b83OZp/39LYNBBhl0MDJprGua+m77p8f+qpoX/M3qP/y9ZcP///Ko57w4zMEB8snDRWc11K88dXLz88q8Zs07/mj9136G5M46CJQFjHoqG8BTniAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: external "react-icons/ci"
const ci_namespaceObject = require("react-icons/ci");
;// CONCATENATED MODULE: ./components/client/about/OurTeam.js







const OurTeam = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "min-h-full pb-14",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "h-full grid grid-cols-1 content-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-2xl mx-auto pb-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-2xl text-[#211A56] font-semibold lg:text-4xl text-center px-5",
                            children: "Meet Our Team"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "py-2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col items-center justify-center bg-white p-4 drop-shadow-lg rounded-lg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "inline-flex shadow-lg border border-gray-200 rounded-full overflow-hidden h-40 w-40",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: rafsun,
                                                alt: "Rafsun Faiz",
                                                className: "h-full w-full"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "mt-4 font-bold text-xl",
                                            children: "Rafsun Faiz"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            className: "mt-2 text-sm font-medium",
                                            children: "Chief Executive Officer"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "flex flex-row mt-4 space-x-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiLinkedin, {
                                                            size: 30
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiTwitter, {
                                                            size: 30
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiFacebook, {
                                                            size: 30
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col items-center justify-center bg-white p-4 drop-shadow-lg rounded-lg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "inline-flex shadow-lg border border-gray-200 rounded-full overflow-hidden h-40 w-40",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: habib,
                                                alt: "Hashan Habib",
                                                className: "h-full w-full"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "mt-4 font-bold text-xl",
                                            children: "Hashan Habib"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            className: "mt-2 text-sm font-medium",
                                            children: "Tech Lead"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "flex flex-row mt-4 space-x-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiLinkedin, {
                                                            size: 30
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiTwitter, {
                                                            size: 30
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiFacebook, {
                                                            size: 30
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col items-center justify-center bg-white p-4 drop-shadow-lg rounded-xl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "inline-flex shadow-lg border border-gray-200 rounded-full overflow-hidden h-40 w-40",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: kaushik,
                                                alt: "team member",
                                                className: "h-full w-full"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "mt-4 font-bold text-xl",
                                            children: "Kaushik Baidya"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            className: "mt-2 text-sm font-medium",
                                            children: "Software Engineer"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "flex flex-row mt-4 space-x-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiLinkedin, {
                                                            size: 30
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiTwitter, {
                                                            size: 30
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "flex items-center justify-center h-8 w-8 text-gray-800",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ci_namespaceObject.CiFacebook, {
                                                            size: 30
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const about_OurTeam = (OurTeam);


/***/ }),

/***/ 6781:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_client_about_HeroAbout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4706);
/* harmony import */ var _components_client_about_HowWeWork__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9011);
/* harmony import */ var _components_client_about_OurTeam__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4198);
/* harmony import */ var _components_client_about_Banner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(518);
/* harmony import */ var _components_client_about_Connect__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1548);
/* harmony import */ var _components_common_Apply__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7628);
/* harmony import */ var _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2758);
/* harmony import */ var _components_MetaComponents__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_Apply__WEBPACK_IMPORTED_MODULE_7__, _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_8__]);
([_components_common_Apply__WEBPACK_IMPORTED_MODULE_7__, _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










// import Instructors from "../components/client/about/Instructors";
async function getStaticProps() {
    const res = await fetch(`${process.env.BASE_URL}/api/about/aboutView`);
    const data = await res.json();
    return {
        props: {
            data
        }
    };
}
// export async function getServerSideProps() {
//   const res = await fetch(`${process.env.BASE_URL}/api/about/aboutView`);
//   const data = await res.json();
//   return { props: { data } };
// }
const AboutUs = ({ data  })=>{
    const { hero , seo , blogs  } = data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: "relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MetaComponents__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                title: seo.title,
                keywords: seo.keywords,
                description: seo.description,
                imageUrl: seo.image,
                appId: seo.facebookApp
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_about_HeroAbout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                data: hero
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_about_Banner__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_about_HowWeWork__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_about_OurTeam__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_Apply__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                data: blogs
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_about_Connect__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutUs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@emailjs/browser");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 8176:
/***/ ((module) => {

module.exports = require("react-spinners");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,3121,5675,676,1664,3221,8244,7222,1519,7628,3987,2758], () => (__webpack_exec__(6781)));
module.exports = __webpack_exports__;

})();