"use strict";
(() => {
var exports = {};
exports.id = 6304;
exports.ids = [6304,3748];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 6229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2113);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth_next__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(870);
/* harmony import */ var _controller_userController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7110);
const bcrypt = __webpack_require__(7096);



async function handler(req, res) {
    const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_0__.unstable_getServerSession)(req, res, _auth_nextauth___WEBPACK_IMPORTED_MODULE_1__.authOptions);
    const userId = req.query.id;
    const method = req.method;
    let result;
    switch(method){
        case session && "GET":
            result = await (0,_controller_userController__WEBPACK_IMPORTED_MODULE_2__/* .getUserById */ .GA)(userId);
            res.json(result);
            break;
        case session && "DELETE":
            result = await (0,_controller_userController__WEBPACK_IMPORTED_MODULE_2__/* .deleteUserById */ .JS)(userId);
            res.json({
                ...result,
                message: `user with userId: ${userId} deleted`
            });
            break;
        case "POST":
            const email = req.body.email;
            const hashedPassword = await bcrypt.hash(req.body.password, 10);
            const username = req.body.username;
            result = await (0,_controller_userController__WEBPACK_IMPORTED_MODULE_2__/* .createUser */ .r4)(email, hashedPassword, username);
            res.json({
                ...result,
                message: `user with name: ${username} created`
            });
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870], () => (__webpack_exec__(6229)));
module.exports = __webpack_exports__;

})();