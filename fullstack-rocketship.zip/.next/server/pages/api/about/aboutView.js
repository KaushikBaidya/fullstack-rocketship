"use strict";
(() => {
var exports = {};
exports.id = 1790;
exports.ids = [1790];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 2998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ updateAboutHero),
/* harmony export */   "q": () => (/* binding */ getAboutHero)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);

const mysql = __webpack_require__(2418);
const getAboutHero = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM about_hero");
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const updateAboutHero = async (updatedTitle, updatedSubtitle, updateImage)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE about_hero SET title = ?, subtitle = ?, image = ? WHERE heroId = 1", [
            updatedTitle,
            updatedSubtitle,
            updateImage
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};



/***/ }),

/***/ 1902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "rockmhvf_rocketship",
    user: "rockmhvf_admin",
    password: "Kgi[0v726uQb"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ }),

/***/ 6552:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_AboutHeroController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2998);
/* harmony import */ var _controller_AboutSEOController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8914);
/* harmony import */ var _controller_blogsController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2955);



async function handler(req, res) {
    const method = req.method;
    switch(method){
        case "GET":
            const seo = await (0,_controller_AboutSEOController__WEBPACK_IMPORTED_MODULE_1__/* .getAboutSeo */ .q)();
            const hero = await (0,_controller_AboutHeroController__WEBPACK_IMPORTED_MODULE_0__/* .getAboutHero */ .q)();
            const blogs = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_2__/* .getBlogsPublished */ .k3)();
            res.json({
                hero,
                seo,
                blogs
            });
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2955,8914], () => (__webpack_exec__(6552)));
module.exports = __webpack_exports__;

})();