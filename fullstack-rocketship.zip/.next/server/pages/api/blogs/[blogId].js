"use strict";
(() => {
var exports = {};
exports.id = 3993;
exports.ids = [3993,3748];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_blogsController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2955);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2113);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(870);



async function handler(req, res) {
    const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_1__.unstable_getServerSession)(req, res, _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__.authOptions);
    const blogId = req.query.blogId;
    const method = req.method;
    let result;
    switch(method){
        case session && "GET":
            result = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_0__/* .getBlogById */ .zv)(blogId);
            res.json(result);
            break;
        case session && "DELETE":
            result = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_0__/* .deleteBlogById */ .o1)(blogId);
            res.json({
                ...result,
                message: `blog with blogId: ${blogId} deleted`
            });
            break;
        case session && "POST":
            const title = req.body.title;
            const description = req.body.description;
            const keywords = req.body.keywords;
            const seoDescription = req.body.seoDescription;
            const permalink = req.body.permalink;
            const img = req.body.img;
            result = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_0__/* .createBlog */ .Vh)(title, description, permalink, keywords, seoDescription, img);
            res.status(201).json({
                ...result,
                message: `blog with title: ${title} created`
            });
            break;
        case session && "PUT":
            const updateTitle = req.body.title;
            const updateDescription = req.body.description;
            const updatePermalink = req.body.permalink;
            const updateKeywords = req.body.keywords;
            const updateSeoDescription = req.body.seoDescription;
            const updateImg = req.body.img;
            result = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_0__/* .updateBlog */ .zZ)(blogId, updateTitle, updateDescription, updatePermalink, updateKeywords, updateSeoDescription, updateImg);
            res.status(204).end("end");
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,2955], () => (__webpack_exec__(1015)));
module.exports = __webpack_exports__;

})();