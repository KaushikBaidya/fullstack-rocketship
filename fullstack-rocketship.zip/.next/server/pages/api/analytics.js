"use strict";
(() => {
var exports = {};
exports.id = 5650;
exports.ids = [5650,3748];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 5649:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./database/db.js
var db = __webpack_require__(1902);
;// CONCATENATED MODULE: ./controller/AnalyticsController.js
const mysql = __webpack_require__(2418);

const getAnalytics = async ()=>{
    try {
        const connection = await mysql.createConnection(db/* default */.Z);
        const [rows] = await connection.query(`SELECT * FROM analytics`);
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const updateAnalytics = async (updateCode)=>{
    try {
        const connection = await mysql.createConnection(db/* default */.Z);
        const [rows] = await connection.query("UPDATE analytics SET code = ? WHERE analyticsId = 1", [
            updateCode
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};


// EXTERNAL MODULE: external "next-auth/next"
var next_ = __webpack_require__(2113);
// EXTERNAL MODULE: ./pages/api/auth/[...nextauth].js
var _nextauth_ = __webpack_require__(870);
;// CONCATENATED MODULE: ./pages/api/analytics/index.js



async function handler(req, res) {
    const session = await (0,next_.unstable_getServerSession)(req, res, _nextauth_.authOptions);
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await getAnalytics();
            res.json(result);
            break;
        case session && "PUT":
            const updateCode = req.body.code;
            result = await updateAnalytics(updateCode);
            res.status(204).end("end");
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870], () => (__webpack_exec__(5649)));
module.exports = __webpack_exports__;

})();