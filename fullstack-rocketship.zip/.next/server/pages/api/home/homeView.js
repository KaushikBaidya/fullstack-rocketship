"use strict";
(() => {
var exports = {};
exports.id = 4212;
exports.ids = [4212];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 2123:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ getHomeHero),
/* harmony export */   "d": () => (/* binding */ updateHomeHero)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const getHomeHero = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM `home_hero`");
        connection.end(console.log("connection ended hero"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const updateHomeHero = async (updatedTitle, updatedSubtitle, updateImage)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE home_hero SET title = ?, subtitle = ?, image = ? WHERE heroId = 1", [
            updatedTitle,
            updatedSubtitle,
            updateImage
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};



/***/ }),

/***/ 2849:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ getVisa),
/* harmony export */   "j": () => (/* binding */ updateVisa)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const getVisa = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM `home_visa`");
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const updateVisa = async (updatedTitle, updatedSubtitle, updatedSubtitle2, updateImage)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE home_visa SET title = ? , subtitle = ? ,subtitle2 = ?, image = ? WHERE visaId = 1", [
            updatedTitle,
            updatedSubtitle,
            updatedSubtitle2,
            updateImage
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};



/***/ }),

/***/ 1902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "rockmhvf_rocketship",
    user: "rockmhvf_admin",
    password: "Kgi[0v726uQb"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ }),

/***/ 310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_blogsController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2955);
/* harmony import */ var _controller_homeHeroController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2123);
/* harmony import */ var _controller_HomeSEOController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1458);
/* harmony import */ var _controller_homeVisaController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2849);
/* harmony import */ var _controller_institutionController__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1321);
/* harmony import */ var _controller_testimonialsController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2880);






async function handler(req, res) {
    const method = req.method;
    switch(method){
        case "GET":
            const seo = await (0,_controller_HomeSEOController__WEBPACK_IMPORTED_MODULE_2__/* .getHomeSeo */ .N)();
            const hero = await (0,_controller_homeHeroController__WEBPACK_IMPORTED_MODULE_1__/* .getHomeHero */ .F)();
            const testimonial = await (0,_controller_testimonialsController__WEBPACK_IMPORTED_MODULE_5__/* .getTestimonials */ .BZ)();
            const institution = await (0,_controller_institutionController__WEBPACK_IMPORTED_MODULE_4__/* .getInstitution */ .fn)();
            const visa = await (0,_controller_homeVisaController__WEBPACK_IMPORTED_MODULE_3__/* .getVisa */ ._)();
            const blogs = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_0__/* .getBlogsPublished */ .k3)();
            res.json({
                hero,
                seo,
                testimonial,
                institution,
                visa,
                blogs
            });
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2955,2880,1321,1458], () => (__webpack_exec__(310)));
module.exports = __webpack_exports__;

})();