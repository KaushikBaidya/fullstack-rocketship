"use strict";
(() => {
var exports = {};
exports.id = 2037;
exports.ids = [2037,3748];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 7903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_HomeSEOController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1458);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2113);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(870);



async function handler(req, res) {
    const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_1__.unstable_getServerSession)(req, res, _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__.authOptions);
    const method = req.method;
    let result;
    switch(method){
        case session && "GET":
            result = await (0,_controller_HomeSEOController__WEBPACK_IMPORTED_MODULE_0__/* .getHomeSeo */ .N)();
            res.json(result);
            break;
        case session && "PUT":
            const updateTitle = req.body.title;
            const updateDescription = req.body.description;
            const updateKeywords = req.body.keywords;
            const updatefacebook = req.body.facebookApp;
            const updateImage = req.body.image;
            result = await (0,_controller_HomeSEOController__WEBPACK_IMPORTED_MODULE_0__/* .updateHomeSeo */ .s)(updateTitle, updateDescription, updateKeywords, updatefacebook, updateImage);
            res.status(204).end("end");
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [870,1458], () => (__webpack_exec__(7903)));
module.exports = __webpack_exports__;

})();