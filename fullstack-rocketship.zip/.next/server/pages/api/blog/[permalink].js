"use strict";
(() => {
var exports = {};
exports.id = 4481;
exports.ids = [4481];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 1902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "rockmhvf_rocketship",
    user: "rockmhvf_admin",
    password: "Kgi[0v726uQb"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ }),

/***/ 5817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_blogsController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2955);

async function handler(req, res) {
    const permalink = req.query.permalink;
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_0__/* .getBlogPermalink */ .$Y)(permalink);
            res.json(result);
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2955], () => (__webpack_exec__(5817)));
module.exports = __webpack_exports__;

})();