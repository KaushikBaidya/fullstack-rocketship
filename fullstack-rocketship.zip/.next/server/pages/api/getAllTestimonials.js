"use strict";
(() => {
var exports = {};
exports.id = 3289;
exports.ids = [3289];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 1902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "rockmhvf_rocketship",
    user: "rockmhvf_admin",
    password: "Kgi[0v726uQb"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ }),

/***/ 7503:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _controller_testimonialsController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2880);

async function handler(req, res) {
    const result = await (0,_controller_testimonialsController__WEBPACK_IMPORTED_MODULE_0__/* .getTestimonials */ .BZ)();
    res.json(result);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2880], () => (__webpack_exec__(7503)));
module.exports = __webpack_exports__;

})();