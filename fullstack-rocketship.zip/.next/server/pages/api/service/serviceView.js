"use strict";
(() => {
var exports = {};
exports.id = 4203;
exports.ids = [4203];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 1902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "rockmhvf_rocketship",
    user: "rockmhvf_admin",
    password: "Kgi[0v726uQb"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ }),

/***/ 1402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_blogsController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2955);
/* harmony import */ var _controller_institutionController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1321);
/* harmony import */ var _controller_ServiceHeroController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1706);
/* harmony import */ var _controller_ServiceSEOController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9532);
/* harmony import */ var _controller_testimonialsController__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2880);





async function handler(req, res) {
    const method = req.method;
    switch(method){
        case "GET":
            const seo = await (0,_controller_ServiceSEOController__WEBPACK_IMPORTED_MODULE_3__/* .getServiceSeo */ .I)();
            const hero = await (0,_controller_ServiceHeroController__WEBPACK_IMPORTED_MODULE_2__/* .getServiceHero */ .I)();
            const institution = await (0,_controller_institutionController__WEBPACK_IMPORTED_MODULE_1__/* .getInstitution */ .fn)();
            const testimonial = await (0,_controller_testimonialsController__WEBPACK_IMPORTED_MODULE_4__/* .getTestimonials */ .BZ)();
            const blogs = await (0,_controller_blogsController__WEBPACK_IMPORTED_MODULE_0__/* .getBlogsPublished */ .k3)();
            res.json({
                hero,
                seo,
                testimonial,
                blogs,
                institution
            });
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2955,2880,1321,9532,1706], () => (__webpack_exec__(1402)));
module.exports = __webpack_exports__;

})();