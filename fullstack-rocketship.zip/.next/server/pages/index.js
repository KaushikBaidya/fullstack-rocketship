"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 1940:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/picture.e5c33a70.png","height":470,"width":557,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA8klEQVR4nAHnABj/Aeva6ADk7u5DCQwGouPWxBrq0LjjA/7pkleGvoy2zNgAAeXS5Cju/vPNFhcRCuXk4/7EkU4CIj55AA0VJKf9UUpaAZtuda8uUE1QISkk++jm5gXRwLz/Ok5h/Pjs5wX6+vSGAcOwq+/46doQLUdZAOju8QD19QEAFRcZ//XbwgHn4NToAamNff8XKDL9JC0yAbS0swEdHCoAIiQn/Pzq2AXu5dPYATgiGrgrNDZHEwwRABoqIgAuMTcAHh8xAPnz7fT648VKAQAAPAsAAMSBYjMMTzxVaxA2S2H2CgwWxfLy8oAM+eXazYtuOYIm+XAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 1144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ home_CollegeCoaching)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/gallery/advantages.png
/* harmony default export */ const advantages = ({"src":"/_next/static/media/advantages.5274043e.png","height":439,"width":499,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA2ElEQVR42mN4bWnX8tLWac9TFy+jt3Iq3V/V1J0YGBgYnjAwKDOAwKvg8A8fU9P/P3Ryvb6ZybBxjpRL8QMr511vvf3+PrRxLGZ4YmTsvE3X4UWDrOMuBgYGhnYGS+37Tp7/30bG/L9p53SYAQJC5Rk4glsZGHz8GMRCCrqEHXtuMzBE9TAwyDGAgByXn9RJe78JV+28PuzQd61nYHjOyIAMXjMwqL8Ljfj/KTPn/1M3j6Mgsff+4ezbJXmZGEDgJgMD+wMXj+l3/YNPH7J3iQSJfY+NA0sCAObeSP5WM3CyAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/client/home/CollegeCoaching.js



// import visa from "../../../public/icons/visa.png";
// import hat from "../../../public/icons/hat.png";
// import library from "../../../public/icons/librarry.png";


const CollegeCoaching = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full mt-5 lg:mt-20",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "max-w-5xl mx-auto text-center px-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-2xl lg:text-4xl font-semibold text-[#221a55] px-10 py-2",
                        children: "College Admissions Counseling"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-lg",
                        children: "Bengali students sometimes find it challenging to apply to their preferred college in the US. But do not worry, Rocketship's admission experts help you navigate the college admissions process through personalized and proven solutions."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "xl:max-w-screen-xl grid grid-cols-1 lg:grid-cols-2 pb-5 lg:pb-20 mx-auto z-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[85%] bg-transparent bg-center bg-[length:350px] bg-no-repeat mx-auto flex flex-wrap items-center justify-around m-5 gap-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: advantages,
                            alt: "perks",
                            width: 500,
                            height: 400
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mx-5 lg:mx-10 text-center lg:text-left",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "text-xl lg:text-2xl font-medium text-[#211A53] py-10 text-left",
                                children: "Rocketship will help you succeed in securing admissions by thoroughly preparing you"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-base lg:text-lg text-left lg:pr-5",
                                children: "With one-on-one guidance on extracurricular profiles, personal statements, course selection, college applications, and unlimited support, our team of experts helps students from all over the globe earn acceptance into the United States's most elite colleges, including Harvard, MIT, Amherst, Stanford, UCLA, NYU, Johns Hopkins, UPenn and more."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-base lg:text-lg text-left lg:pr-5 mt-5",
                                children: "Learn the ropes from our college admissions coaches with the most comprehensive curriculum."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mt-10 text-sm font-medium",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/ourservice",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "px-9 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                            children: "Learn More"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/contactus",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "px-10 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                            children: "Contact Us"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const home_CollegeCoaching = (CollegeCoaching);


/***/ }),

/***/ 3739:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Connect = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "bg-white my-10",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-sbanner",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-[#221a55dc] text-white items-center backdrop-blur-none gap-y-3 px-10 py-20 mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "xl:max-w-4xl mx-auto flex flex-col md:flex-row justify-around gap-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex justify-center items-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-white text-2xl lg:w-3/4 text-center md:text-left",
                                children: "Want to go to United States and attend your dream school?"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/contactus",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "px-5 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                    children: "Contact Us"
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Connect);


/***/ }),

/***/ 3320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_Loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8652);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);



// import { useGetData } from "../../../hooks/DataApi";


// import { Error } from "../../common/Error";
const HeroSection = ({ data  })=>{
    if (!data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Loader__WEBPACK_IMPORTED_MODULE_3__/* .Loader */ .a, {});
    const tmp = data;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "bg-white antialiased ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "lg:bg-sbanner bg-fixed",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full bg-gradient-to-r from-[#302764fa] to-[#9588e9e8]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "xl:max-w-screen-xl mx-auto grid grid-cols-1 lg:grid-cols-2 py-20 z-10",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mx-5 text-center lg:text-left",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-2xl lg:text-[50px] leading-snug font-medium text-white pb-5 pt-20",
                                    children: tmp.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: " text-white text-center lg:text-left text-base lg:text-lg pr-5",
                                    children: tmp.subtitle
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mt-10 text-sm font-medium",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/ourservice",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "px-9 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                                children: "College Admission"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/aboutus",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "px-10 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                                children: "About Us"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "hidden lg:flex items-center justify-center mx-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "max-w-[550px] pt-20",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: tmp.image,
                                    //   src={`https://drive.google.com/uc?export=view&id=${tmp.image1}`}
                                    width: 550,
                                    height: 300,
                                    alt: "USA education"
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroSection);


/***/ }),

/***/ 7832:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ home_OtherPrograms)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/icons/accepted.png
/* harmony default export */ const accepted = ({"src":"/_next/static/media/accepted.6660fc8a.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAArklEQVR42mMgGsw8laS2+HxR6LKL5VGzTqVooEhOOREpPeVErP7i8+Ucqy/Xc087EW849US0NFhy0rFEplmnUg1nnkqzmHEy0W/K8ViPaSeSzIBiRtOOpzMzTDmWwjTndIbxzFMplrNPp/tPO5HiNP1kitmc0+lGU4+nMoNNmXoiRmb6yQT9ZReqOZZfrOCafjJRf9rJOGkUd8w5k6627EJp6NILJaGzT6eoEu07AJvlRs6ItlPVAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/sheets.png
/* harmony default export */ const sheets = ({"src":"/_next/static/media/sheets.dc00b3ff.png","height":102,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAU0lEQVR42gFIALf/APLz5+Dd7vz8ANrV7ujp497mANOzw6+r3+boAOXNpIOS4uzqAO3Uzr/Q8OvqAPPWs6KQzu7pAPjhsZi84+zrAP7l4t/w9t3ppAs2FmW6z+gAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/running.png
/* harmony default export */ const running = ({"src":"/_next/static/media/running.4ca61b50.png","height":600,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAWElEQVR42k3IoQ2DQAAAwGu/qaloKprUlAFA4vEIBOBIwJCg2INJsIzAAAzBLEg4eRCc7sBLLVYp4SPTauw2ETzlEotBb/QF3mYd/hAwWaUANxR+CNfiARzOpQmH9rDf6QAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/client/home/OtherPrograms.js





const OtherPrograms = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "min-h-full py-14 px-10",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "h-full grid grid-cols-1 content-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "max-w-5xl mx-auto pb-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-2xl lg:text-4xl font-semibold text-[#221a55] px-5 py-2 text-center",
                        children: "We help you grow, thrive, and be the star student you aim to be in the US."
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "py-2",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:max-w-screen-xl grid grid-cols-1 md:grid-cols-3 mx-auto gap-10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex bg-white flex-col h-full py-10 px-5 rounded-tl-3xl rounded-br-3xl drop-shadow-2xl justify-evenly",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "py-2 w-14",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: accepted,
                                            alt: "accepted"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-[#211A56] font-semibold text-xl",
                                        children: "2x more to be accepted"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "",
                                        children: "Become 2x more likely get your visa approved and nail the interview and get hired."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex bg-white flex-col h-full py-10 px-5 rounded-tl-3xl rounded-br-3xl drop-shadow-2xl justify-evenly",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "py-2 w-14",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: sheets,
                                            alt: "documents"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-[#211A56] font-semibold text-xl",
                                        children: "Documents Ready."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "",
                                        children: "Get a complete audit of the documents need and guidance on what to present."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex bg-white flex-col h-full py-10 px-5 rounded-tl-3xl rounded-br-3xl drop-shadow-2xl justify-evenly",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "py-2 w-14",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: running,
                                            alt: "running"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-[#211A56] font-semibold text-xl",
                                        children: "Cut 2 Months"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "",
                                        children: "Expedite the visa process by 2 months with Rocketship"
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const home_OtherPrograms = (OtherPrograms);


/***/ }),

/***/ 670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ home_OurPrograms)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/icons/flag.png
/* harmony default export */ const flag = ({"src":"/_next/static/media/flag.df875f7f.png","height":63,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAsUlEQVR42mM4eWDXhq0Hz52/umH9znev3/z////f339AwHDy4B4GhnR+8xIGhZyVLb0fnj0FyoEkvr57OnvuqvyqaallU+e3T90/fdqVI0f+AiW+f3pz98iBq1u2Xtiw8eq6dftnzjwyf/6XT58Yfn7/dHHdijPTZ15avfro3Hl7OzsPzpx1fvNmht8/vz25cvbDy1e/f/9+8+zZ81u3Prx9+/z+A4a/f379/PL2PwYAAN0vhQQ9UeGrAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/icons/counselling.png
/* harmony default export */ const counselling = ({"src":"/_next/static/media/counselling.208a6adf.png","height":70,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAuElEQVR42h2OOw6CQBBA55p6C2/g5xYae0uNFn4SNQGtLMSGWGCAoMsukMAKssCy6+gkk7z3ismA1rqsCpI+qqYU9Q9EXWIE3PBtDw9Auesn9ugIaeljBKW0eWOF4Eq1SslcZIYVYQSWZJMV4Xmr/4MwXhIWZzCb73uTYG6wgPIn5QuToWKE1c7sDrbTpesE1H1FCJ3+FiOQkF2ty+bs3T3qBPH65KISGkEjJZ4uPvhsJaoaAbWR8gtxIaYkl1bh/gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/university.png
/* harmony default export */ const university = ({"src":"/_next/static/media/university.6170b982.png","height":73,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAUElEQVR42gUAMQqAIPD+/50sE0EKWzTHmlIEKazFG4zaugDCEGNAAudTKck7sKpvmFAWHs1bLvQLlc3LarobUH10VY0gJ9oyaQlmPPK5D/YHkuk1q+m0vrkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/client/home/OurPrograms.js





const OurPrograms = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "min-h-full pb-14 px-10",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "h-full grid grid-cols-1 content-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "max-w-5xl mx-auto pb-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-2xl lg:text-4xl font-semibold text-[#221a55] px-2 py-2 text-center",
                        children: "Achieve your dreams of studying in America with Rocketship. We will take you there"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "py-2",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:max-w-screen-xl grid grid-cols-1 md:grid-cols-3 mx-auto gap-10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex bg-white flex-col h-full py-10 px-5 rounded-tl-3xl rounded-br-3xl drop-shadow-2xl justify-evenly",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "py-2 w-14",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: flag,
                                            alt: "US flag"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-[#211A56] font-semibold text-xl ",
                                        children: "50 States"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "",
                                        children: "Get exposure to college of your choice in any of the states"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex bg-white flex-col h-full py-10 px-5 rounded-tl-3xl rounded-br-3xl drop-shadow-2xl justify-evenly",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "py-2 w-14",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: counselling,
                                            alt: "counseling"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-[#211A56] font-semibold text-xl ",
                                        children: "Dedicated Consultants"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "",
                                        children: "We will have a dedicated consultant for you. From start to finish, our consultants will guide you step by step."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex bg-white flex-col h-full py-10 px-5 rounded-tl-3xl rounded-br-3xl drop-shadow-2xl justify-evenly",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "py-2 w-14",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: university,
                                            alt: "US university"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-[#211A56] font-semibold text-xl ",
                                        children: "90% Acceptance Rate"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "",
                                        children: "Over 90% of the students we work with get into at least 1 of their top 7 school choices."
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const home_OurPrograms = (OurPrograms);


/***/ }),

/***/ 1708:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _common_Loader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8652);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








swiper__WEBPACK_IMPORTED_MODULE_3__["default"].use([
    swiper__WEBPACK_IMPORTED_MODULE_3__.Pagination,
    swiper__WEBPACK_IMPORTED_MODULE_3__.Autoplay
]);
const StudentTestimonial = ({ data  })=>{
    if (!data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Loader__WEBPACK_IMPORTED_MODULE_5__/* .Loader */ .a, {});
    const tmp = data;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "bg-white antialiased ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-sbanner bg-fixed",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-[#221a55dc] text-white backdrop-blur-none gap-y-3 px-10 py-20 justify-items-center content-center mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "xl:max-w-screen-xl mx-auto grid grid-cols-1 lg:grid-cols-5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-span-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-left text-base font-thin px-3",
                                    children: "Reviews"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-xl md:text-3xl px-3",
                                    children: "Happy students say about us"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full md:mt-0 sm:mt-14 mt-10 col-span-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                                    slidesPerView: "auto",
                                    spaceBetween: 30,
                                    loop: true,
                                    autoplay: {
                                        delay: 3000,
                                        disableOnInteraction: false
                                    },
                                    breakpoints: {
                                        540: {
                                            slidesPerView: 1,
                                            spaceBetween: 30
                                        },
                                        768: {
                                            slidesPerView: 1,
                                            spaceBetween: 40
                                        }
                                    },
                                    children: tmp.length > 0 ? tmp.map((item)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-full flex flex-col mx-auto my-2 bg-white rounded-tl-3xl rounded-br-3xl p-5 justify-evenly h-full",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "w-[70px] h-[70px] lg:w-[100px] lg:h-[100px] ml-5 mt-2 rounded-full overflow-hidden",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                            src: item.img,
                                                            alt: item.title,
                                                            width: 200,
                                                            height: 200
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm lg:text-base text-justify text-gray-700 m-5",
                                                        children: item.description
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "text-lg lg:text-xl text-[#221a55] font-semibold mx-5",
                                                        children: item.title
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm text-gray-700 mx-5 my-2",
                                                        children: item.designation
                                                    })
                                                ]
                                            })
                                        }, item.testimonialId);
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-center text-red-700",
                                        children: "Not Available"
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StudentTestimonial);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7848:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_gallery_picture_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1940);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _common_Loader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8652);
/* harmony import */ var _common_Error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2563);
/* harmony import */ var _hooks_DataApi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3221);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_DataApi__WEBPACK_IMPORTED_MODULE_7__]);
_hooks_DataApi__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const VisaProcess = ({ data  })=>{
    // const {
    //   data: list,
    //   error,
    //   isLoading,
    //   isError,
    // } = useGetData("visa", `/home/visa`);
    if (!data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Loader__WEBPACK_IMPORTED_MODULE_5__/* .Loader */ .a, {});
    // if (isError) return <Error message={error.message} />;
    const tmp = data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "w-full pt-20",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "max-w-5xl mx-auto text-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-2xl lg:text-4xl font-semibold text-[#221a55] px-10 py-2 text-center",
                    children: "Visa Process"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "xl:max-w-screen-xl grid grid-cols-1 lg:grid-cols-2 pb-5 lg:py-10 mx-auto",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mx-5 lg:mx-10 text-center lg:text-left",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-xl lg:text-2xl font-semibold text-[#211A53] pb-5 text-left",
                                children: tmp.title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-lg text-left md:text-justify pr-5",
                                children: tmp.subtitle
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-lg text-left md:text-justify pr-5 mt-5",
                                children: tmp.subtitle2
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mt-10 text-sm font-medium",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        href: "/ourservice",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "px-9 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                            children: "Learn More"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        href: "/contactus",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "px-10 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                            children: "Contact Us"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center justify-center mx-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "max-w-[500px] z-30",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: tmp.image,
                                //   src={`https://drive.google.com/uc?export=view&id=${tmp.image1}`}
                                width: 500,
                                height: 300,
                                alt: "visa processing"
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VisaProcess);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4369:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Index),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_client_home_HeroSection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3320);
/* harmony import */ var _components_client_home_OurPrograms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(670);
/* harmony import */ var _components_client_home_CollegeCoaching__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1144);
/* harmony import */ var _components_client_home_OtherPrograms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7832);
/* harmony import */ var _components_client_home_Connect__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3739);
/* harmony import */ var _components_client_home_VisaProcess__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7848);
/* harmony import */ var _components_common_Apply__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7628);
/* harmony import */ var _components_MetaComponents__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3987);
/* harmony import */ var _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2758);
/* harmony import */ var _components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3524);
/* harmony import */ var _components_client_home_StudentTestimonial__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1708);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_client_home_VisaProcess__WEBPACK_IMPORTED_MODULE_6__, _components_common_Apply__WEBPACK_IMPORTED_MODULE_7__, _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_9__, _components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_10__, _components_client_home_StudentTestimonial__WEBPACK_IMPORTED_MODULE_11__]);
([_components_client_home_VisaProcess__WEBPACK_IMPORTED_MODULE_6__, _components_common_Apply__WEBPACK_IMPORTED_MODULE_7__, _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_9__, _components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_10__, _components_client_home_StudentTestimonial__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












async function getStaticProps() {
    const res = await fetch(`${process.env.BASE_URL}/api/home/homeView`);
    const data = await res.json();
    return {
        props: {
            data
        }
    };
}
// export async function getServerSideProps() {
//   const res = await fetch(`https://rocketshipedu.com/api/home/homeView`);
//   const data = await res.json();
//   return { props: { data } };
// }
function Index({ data  }) {
    const { hero , seo , testimonial , institution , visa , blogs  } = data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MetaComponents__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                title: seo.title,
                keywords: seo.keywords,
                description: seo.description,
                imageUrl: seo.image,
                appId: seo.facebookApp
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_HeroSection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                data: hero
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_CollegeCoaching__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_OurPrograms__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                data: institution
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_StudentTestimonial__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                data: testimonial
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_VisaProcess__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                data: visa
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_OtherPrograms__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_Apply__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                data: blogs
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_Connect__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@emailjs/browser");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 8176:
/***/ ((module) => {

module.exports = require("react-spinners");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,3121,5675,676,1664,3221,8244,7222,1519,7628,3987,2758,3524], () => (__webpack_exec__(4369)));
module.exports = __webpack_exports__;

})();