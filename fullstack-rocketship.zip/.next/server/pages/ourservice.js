"use strict";
(() => {
var exports = {};
exports.id = 8447;
exports.ids = [8447];
exports.modules = {

/***/ 1532:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/feedback.90ba24e7.png","height":781,"width":1024,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAA0UlEQVR4nAHGADn/AXN7jAAPA/gvEA4GfgEFBiXu39brDhchqhIfEJnj3e0AAaa0wzi+sqa+7OXhCTQyLwD++/wAGRkWAPL1+MABCQxSAZKRmLDV0s1PEOjF+uYSMgUdIin/CAf//fPt8AUHBAG1AZWMdKMD69BcBObp+f8VLwX4Dxr/4/P//TUyLQb08O/DAde0Vy/87gvA+wkzEA0C9gDx6NwA3f0fAD9XZdcXFhROAdPHqgARFicl//brag4ODCXo6PX35/IFwbjW1Zx0WlT4jB1d1vv5of8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 1391:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ service_CollegeGuidance)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/icons/research.png
/* harmony default export */ const research = ({"src":"/_next/static/media/research.4b800baf.png","height":959,"width":850,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAfklEQVR42mNgYKhnmOcV5cIgwgACEooMyinex7gYzJhVGBQYGLT9OBj8GIwYQpXZVXUZpFQZHCMcrjV4WDM4MsgxMKgwWIc5XK3xsmGwmRDE4Gg0U5whkMGEIZSBvd6HocRoYhCD4X9mFnNhFQZJhmqGBgZ1SQYzRgk+BgYGAOFLFSxEAoYyAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/application.png
/* harmony default export */ const application = ({"src":"/_next/static/media/application.c8d58a17.png","height":1060,"width":880,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAgUlEQVR42mNgr2VZzTSFeQbLFNZNnMEMzGt5U3nTeLL5ojjr2ToYmObwpXNM55jG3ctRwlbDwDSPN4dzJtcM7iqWClag7ALeeJ5a3pIQJjZb7lQGluV8guwMjAz8Qfzh/AEMrFvYy9hD+Fz487mmi7oycLiwV7PUc/oJ6PFZiikDALVrGkbv0CHaAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/guidence.png
/* harmony default export */ const guidence = ({"src":"/_next/static/media/guidence.ae9765bf.png","height":112,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAfklEQVR42mNgYJPS0fPSqtP1ktERY2NQ1lFMVqvRc1WrUUpW02HQctEsV+TUYZDn1CjXdGHQLVJ2ZWCQYmdgUHLTLWLQ91Av0OeVYdDn1SjQd2dQMVBLVsxiEFbMUk1WNmCw5tIwVuswmafermFsxcXAwKjEoJ2otAyIGRgYAQZbFZTdYabOAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/testing.png
/* harmony default export */ const testing = ({"src":"/_next/static/media/testing.76718f62.png","height":756,"width":550,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAmElEQVR42g3JPU4CQRgA0Le7EzAmGknojBoOYGdjbOy9ipfxRvYewFYbjYUobPib5ZuB9r0GdxcnrteD8xxaLPGROm7+txb4PBvZ9tkUs/bx1unbi/vnJ/mIy9nUO7pkEGVhLEsY56xFaetOs59TViqqUOEYasxFrFVEEwJS3Wjqt5R6MCp7oPvdeegHP69fJn/halVcViYH81ZFLQdbHWQAAAAASUVORK5CYII=","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/icons/easyreview.png
/* harmony default export */ const easyreview = ({"src":"/_next/static/media/easyreview.92e3bb35.png","height":599,"width":462,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAQAAABwz0azAAAAWElEQVR42jXHOw5FUBSG0b+/9Z3/PCQGINF6NR6ROMVGEMrtQ0S3lvRLq47aO0qURAPBAz0VmjjOhQMjQ+YLI+ubBxPbE5d98RzNN2Z2N+JYLUbwkaLR/wJ+EVZqrU9V0QAAAABJRU5ErkJggg==","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/gallery/options.jpeg
/* harmony default export */ const options = ({"src":"/_next/static/media/options.d88b300a.jpeg","height":560,"width":560,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAAL/2gAMAwEAAhADEAAAAKkFf//EABsQAAICAwEAAAAAAAAAAAAAAAIDARIABFFB/9oACAEBAAE/AF7U7jAlBQSRO1/C5Xuf/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFhEBAQEAAAAAAAAAAAAAAAAAAQIA/9oACAEDAQE/ALCaQ3//2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/client/service/CollegeGuidance.js









const CollegeGuidance = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "py-4 sm:py-8 lg:py-10",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-4 mx-auto max-w-7xl sm:px-6 lg:px-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-w-6xl mx-auto text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-2xl text-[#211A56] lg:text-4xl font-semibold text-center px-5 mb-4",
                                children: "Our In-Depth Approach to College Guidance"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-[12px] lg:text-[15px] font-medium text-left px-5",
                                children: "We are an innovative college admissions guidance agency. Our in-depth and one-to-one approach to helping Bangladeshi students secure admissions is transforming how students approach and apply to institutes in the US. We help students enroll in the college they prefer. Here are the basic steps you would follow:"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 place-content-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "max-w-7xl mx-auto mt-16 space-y-12",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "relative flex items-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "-ml-0.5 absolute mt-0.5 top-14 left-8 w-px border-l-4 border-dotted border-gray-300 h-full",
                                                "aria-hidden": "true"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRed bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: research,
                                                    width: 40,
                                                    alt: "research"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "ml-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "Complete Research Based on Your Preferences"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-4 text-[.9rem] font-medium",
                                                        children: "The college application can be better understood as the culmination of the growth a student will experience in high school. RocketShip aims towards long-term outcomes that maximize student success, both academically and personally."
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "relative flex items-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "-ml-0.5 absolute mt-0.5 top-14 left-8 w-px border-l-4 border-dotted border-gray-300 h-full",
                                                "aria-hidden": "true"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRed bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: application,
                                                    width: 30,
                                                    alt: "application"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "ml-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "Application Guidance"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-4 text-[.9rem] font-medium ",
                                                        children: "Typically you would need to complete your HSC or A-levels before attending a undergraduate college in United States. We recommend you apply one year before you pass your HSC / A-Levels. Our consultants will guide you step by step on the application: submitting transcripts and other necessary documents"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "relative flex items-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "-ml-0.5 absolute mt-0.5 top-14 left-8 w-px border-l-4 border-dotted border-gray-300 h-full",
                                                "aria-hidden": "true"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRed bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: guidence,
                                                    width: 35,
                                                    alt: "guidence"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "ml-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "Expert Guidance"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-4 text-[.9rem] font-medium",
                                                        children: "Our counselors graduated from the top universities and colleges of the nation including UC Berkeley and Georgetown among others. Our team offers strategic college guidance with a professional and individualized touch. You can trust our coaches because they care for you, are approachable, and are relatable."
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "relative flex items-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "-ml-0.5 absolute mt-0.5 top-14 left-8 w-px border-l-4 border-dotted border-gray-300 h-full",
                                                "aria-hidden": "true"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRed bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: testing,
                                                    width: 30,
                                                    alt: "testing"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "ml-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "Testing Requirements"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-4 text-[.9rem] font-medium",
                                                        children: "Universities have testing requirements such as IELTS, TOFL or the SAT. We will guide on most suitable test needed and help you succeed on these exams"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "relative flex items-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative flex items-center justify-center flex-shrink-0 w-16 h-16 bg-shapeRed bg-no-repeat",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: easyreview,
                                                    width: 30,
                                                    alt: "essay review"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "ml-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "Essay Review"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-4 text-[.9rem] font-medium",
                                                        children: "Having a solid admission essay and supplemental essay is key for college admission. Rocketship can help you craft the compelling college admissions essay you need to convince US-based institutes. Your personal and supplementary essays can make or break the chance of getting into your dream school."
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "max-w-[500px] flex items-center justify-center mx-2 lg:mx-auto my-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: options,
                                    width: 550,
                                    height: 550,
                                    alt: ""
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const service_CollegeGuidance = (CollegeGuidance);


/***/ }),

/***/ 6866:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Faqs)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/gallery/faqs.jpg
/* harmony default export */ const faqs = ({"src":"/_next/static/media/faqs.06890dd6.jpg","height":761,"width":1024,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAAAQEBAQAAAAAAAAAAAAAAAAAAAQT/2gAMAwEAAhADEAAAAIIX/8QAHRAAAgEEAwAAAAAAAAAAAAAAAQMCAAQSEwURIf/aAAgBAQABPwBHMX61bDG32SVFneJOJIy8r//EABgRAAMBAQAAAAAAAAAAAAAAAAECAyEA/9oACAECAQE/ABexeoNDjZ3/xAAYEQEAAwEAAAAAAAAAAAAAAAACABEykf/aAAgBAwEBPwAE1k8n/9k=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./components/client/service/Faqs.js




const Faq = ()=>{
    const [show, setShow] = (0,external_react_.useState)(false);
    const [show2, setShow2] = (0,external_react_.useState)(false);
    const [show3, setShow3] = (0,external_react_.useState)(false);
    const [show4, setShow4] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "xl:max-w-screen-xl mx-auto md:py-5 px-5 lg:px-20",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "grid grid-cols-1 lg:grid-cols-2 md:space-x-16 mt-8",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: faqs,
                        alt: "Img of Glass bottle",
                        className: "w-full md:block hidden",
                        width: 900,
                        height: 700
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: " font-semibold lg:text-3xl text-xl lg:leading-9 md:leading-7 leading-9 text-gray-800 mb-5 lg:mb-10",
                            children: "Frequently Asked Questions"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-between items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-base font-medium leading-5 text-gray-800",
                                            children: "What are the requirements to study in the USA for Undergraduate Students?"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            "aria-label": "too",
                                            className: "cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800",
                                            onClick: ()=>setShow(!show),
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 20 20",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        className: show ? "hidden" : "block",
                                                        d: "M10 4.1665V15.8332",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M4.16602 10H15.8327",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-normal text-base leading-6 text-gray-600 mt-4 w-11/12 " + (show ? "block" : "hidden"),
                                    children: "If you are a student from Bangladesh, you need to have an HSC+ One-year completion certificate from any Bangladeshi university. A study gap maximum of 1.5 years is accepted with an HSC result that is not below a GPA of 4.00 out of 5.00."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                            className: " my-7 bg-gray-200"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: " flex justify-between items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-base font-medium leading-5 text-gray-800",
                                            children: "What are the requirements to study in the USA for Postgraduate Students?"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            "aria-label": "too",
                                            className: " cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800",
                                            onClick: ()=>setShow2(!show2),
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 20 20",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        className: show2 ? "hidden" : "block",
                                                        d: "M10 4.1665V15.8332",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M4.16602 10H15.8327",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-normal text-base leading-6 text-gray-600 mt-4 w-11/12 " + (show2 ? "block" : "hidden"),
                                    children: "For bachelor (Hons, BSc, BBA, BA) result not be below CGPA 3. GMAT is required for business courses and GRE will be required as well."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                            className: " my-7 bg-gray-200"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: " flex justify-between items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-base font-medium leading-5 text-gray-800",
                                            children: "What Language Proficiency do I need to study in the USA?"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            "aria-label": "too",
                                            className: " cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800",
                                            onClick: ()=>setShow3(!show3),
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 20 20",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        className: show3 ? "hidden" : "block",
                                                        d: "M10 4.1665V15.8332",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M4.16602 10H15.8327",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-normal text-base leading-6 text-gray-600 mt-4 w-11/12 " + (show3 ? "block" : "hidden"),
                                    children: "For English medium Study: IELTS Score of 6.5 minimum or an ESL program with the main course is required to study in the USA."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                            className: " my-7 bg-gray-200"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: " flex justify-between items-center cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-base font-medium leading-5 text-gray-800",
                                            children: "What are the Required Documents for a USA study visa?"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            "aria-label": "too",
                                            className: " cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800",
                                            onClick: ()=>setShow4(!show4),
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 20 20",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        className: show4 ? "hidden" : "block",
                                                        d: "M10 4.1665V15.8332",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M4.16602 10H15.8327",
                                                        stroke: "#1F2937",
                                                        strokeWidth: "1.25",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "font-normal text-base leading-6 text-gray-600 mt-4 w-11/12 " + (show4 ? "block" : "hidden"),
                                    children: [
                                        "You will need the following documents:",
                                        " ",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list-disc lg:pl-10",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Passport size photo (white background)"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Curriculum Vitae (CV)"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "IELTS Certificate (6.0 or 6.5 min)"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Two Recommendation Letters (for Masters)"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Personal letter of motivation stating your career objectives (for Masters)"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                            className: " my-7 bg-gray-200"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Faqs = (Faq);


/***/ }),

/***/ 7867:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_Loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8652);




const HeroService = ({ data  })=>{
    if (!data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Loader__WEBPACK_IMPORTED_MODULE_3__/* .Loader */ .a, {});
    const tmp = data;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "w-full md:h-[550px] overflow-hidden",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "relative hidden lg:block",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                        id: "wave",
                        className: "absolute top-16",
                        style: {
                            transform: "rotate(180deg)",
                            transition: "0.3s"
                        },
                        viewBox: "10 0 1240 500",
                        version: "1.1",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                    id: "sw-gradient-0",
                                    x1: "0",
                                    x2: "0",
                                    y1: "1",
                                    y2: "0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                            stopColor: "rgba(106, 92, 204, 1)",
                                            offset: "0%"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                            stopColor: "rgba(106, 92, 204, 1)",
                                            offset: "100%"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                style: {
                                    transform: "translate(0, 20px)",
                                    opacity: "1"
                                },
                                fill: "url(#sw-gradient-0)",
                                d: "M0,294L60,302.2C120,310,240,327,360,310.3C480,294,600,245,720,212.3C840,180,960,163,1080,155.2C1200,147,1320,147,1440,130.7C1560,114,1680,82,1800,81.7C1920,82,2040,114,2160,138.8C2280,163,2400,180,2520,163.3C2640,147,2760,98,2880,114.3C3000,131,3120,212,3240,212.3C3360,212,3480,131,3600,89.8C3720,49,3840,49,3960,81.7C4080,114,4200,180,4320,204.2C4440,229,4560,212,4680,245C4800,278,4920,359,5040,334.8C5160,310,5280,180,5400,155.2C5520,131,5640,212,5760,261.3C5880,310,6000,327,6120,351.2C6240,376,6360,408,6480,400.2C6600,392,6720,343,6840,343C6960,343,7080,392,7200,351.2C7320,310,7440,180,7560,114.3C7680,49,7800,49,7920,114.3C8040,180,8160,310,8280,326.7C8400,343,8520,245,8580,196L8640,147L8640,490L8580,490C8520,490,8400,490,8280,490C8160,490,8040,490,7920,490C7800,490,7680,490,7560,490C7440,490,7320,490,7200,490C7080,490,6960,490,6840,490C6720,490,6600,490,6480,490C6360,490,6240,490,6120,490C6000,490,5880,490,5760,490C5640,490,5520,490,5400,490C5280,490,5160,490,5040,490C4920,490,4800,490,4680,490C4560,490,4440,490,4320,490C4200,490,4080,490,3960,490C3840,490,3720,490,3600,490C3480,490,3360,490,3240,490C3120,490,3000,490,2880,490C2760,490,2640,490,2520,490C2400,490,2280,490,2160,490C2040,490,1920,490,1800,490C1680,490,1560,490,1440,490C1320,490,1200,490,1080,490C960,490,840,490,720,490C600,490,480,490,360,490C240,490,120,490,60,490L0,490Z"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                                    id: "sw-gradient-1",
                                    x1: "0",
                                    x2: "0",
                                    y1: "1",
                                    y2: "0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                            stopColor: "rgba(33, 26, 83, 1)",
                                            offset: "70%"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                                            stopColor: "rgba(106, 92, 204, 1)",
                                            offset: "100%"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                style: {
                                    transform: "translate(0, 50px)",
                                    opacity: "0.9"
                                },
                                fill: "url(#sw-gradient-1)",
                                d: "M0,343L60,351.2C120,359,240,376,360,326.7C480,278,600,163,720,106.2C840,49,960,49,1080,73.5C1200,98,1320,147,1440,147C1560,147,1680,98,1800,130.7C1920,163,2040,278,2160,294C2280,310,2400,229,2520,220.5C2640,212,2760,278,2880,285.8C3000,294,3120,245,3240,261.3C3360,278,3480,359,3600,392C3720,425,3840,408,3960,351.2C4080,294,4200,196,4320,147C4440,98,4560,98,4680,138.8C4800,180,4920,261,5040,277.7C5160,294,5280,245,5400,253.2C5520,261,5640,327,5760,351.2C5880,376,6000,359,6120,343C6240,327,6360,310,6480,269.5C6600,229,6720,163,6840,187.8C6960,212,7080,327,7200,383.8C7320,441,7440,441,7560,400.2C7680,359,7800,278,7920,269.5C8040,261,8160,327,8280,359.3C8400,392,8520,392,8580,392L8640,392L8640,490L8580,490C8520,490,8400,490,8280,490C8160,490,8040,490,7920,490C7800,490,7680,490,7560,490C7440,490,7320,490,7200,490C7080,490,6960,490,6840,490C6720,490,6600,490,6480,490C6360,490,6240,490,6120,490C6000,490,5880,490,5760,490C5640,490,5520,490,5400,490C5280,490,5160,490,5040,490C4920,490,4800,490,4680,490C4560,490,4440,490,4320,490C4200,490,4080,490,3960,490C3840,490,3720,490,3600,490C3480,490,3360,490,3240,490C3120,490,3000,490,2880,490C2760,490,2640,490,2520,490C2400,490,2280,490,2160,490C2040,490,1920,490,1800,490C1680,490,1560,490,1440,490C1320,490,1200,490,1080,490C960,490,840,490,720,490C600,490,480,490,360,490C240,490,120,490,60,490L0,490Z"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "xl:max-w-screen-xl grid grid-cols-1 md:grid-cols-2 pt-28 pb-5 lg:pb-28 mx-auto z-10",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mx-10 lg:mx-20 text-center z-10",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-[#211A56] lg:text-white text-2xl lg:text-5xl text-center md:text-left font-medium py-5 ",
                                    children: tmp.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-[#211A56] lg:text-white text-base text-center md:text-left lg:text-lg py-5",
                                    children: tmp.subtitle
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-center mx-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "max-w-[500px] z-20",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: tmp.image,
                                    width: 550,
                                    height: 300,
                                    alt: "service"
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroService);


/***/ }),

/***/ 7059:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ service_InnovativeCounselling)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/gallery/counselling.png
/* harmony default export */ const counselling = ({"src":"/_next/static/media/counselling.46cd8da0.png","height":448,"width":436,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBUlEQVR42k2JTUrDUBRG7w7qwLUILkOcd+AOxIkoOBFcgTiSglKpaIspbUJTaWzamvdIXosomGg1PyRBbRLbOG1er1EceOCDj3Pgj8JFqbwp1uqNux49aJ7VNnK3/FvEq9b2A2Wx92KjTikGroeh6+M9YbEkyLvwRPQwiRN8Dd7m/UGfE0KzsRfOk/gTn6nxAZEk2p3DY7wWpIXnusiYgUL5cqEclXAiNgNglerezDTxKwiyR9PCrqpi6vtZalk4PK/uw9r61so0itGbpLyjqHhyWkHnfZrNogSLxZ1V0FrKzyRn7OBIH3KDGNzOP2l3ZfhH4VZW6qyn8dGAcq1908jdEgDAN5Far0l+a5pbAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: external "react-icons/gi"
const gi_namespaceObject = require("react-icons/gi");
;// CONCATENATED MODULE: ./components/client/service/InnovativeCounselling.js





const InnovativeCounselling = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "max-w-6xl mx-auto lg:pb-10",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mb-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-[24px] text-[#211A56] font-semibold lg:text-[36px] text-center px-5",
                        children: "Innovative Counseling"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 lg:grid-cols-2 place-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-col",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "px-5",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center justify-evenly gap-4 mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(gi_namespaceObject.GiGraduateCap, {
                                                    size: 40,
                                                    className: "text-[#ED1D26]"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "One-on-One Customized Guidance Sessions"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-1 text-[.9rem] font-medium",
                                                        children: "You can engage in a personalized advising session with the best counselors in the industry to support your college and academic journey"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center justify-between gap-4 mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(gi_namespaceObject.GiGraduateCap, {
                                                    size: 40,
                                                    className: "text-[#ED1D26]"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "Parent Check-Ins"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-1 text-[.9rem] font-medium",
                                                        children: "SCommunicate with us and get to know your child's success and progress. Get tips about how to best support their journey to their dream institute."
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center justify-between gap-4 mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(gi_namespaceObject.GiGraduateCap, {
                                                    size: 40,
                                                    className: "text-[#ED1D26]"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "Unlimited Resume and Essay Revues"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-1 text-[.9rem] font-medium",
                                                        children: "Share unlimited resumes and essays and get comprehensive feedback from us"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center justify-between gap-4 mt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(gi_namespaceObject.GiGraduateCap, {
                                                    size: 40,
                                                    className: "text-[#ED1D26]"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "text-[1.2rem] font-semibold text-[#211A56]",
                                                        children: "College Thematic and Exploration Workshops"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-1 text-[.9rem] font-medium",
                                                        children: "Participate in virtual workshops to work and interact with our coaches from the top schools in the nation."
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "max-w-[500px] mx-2 lg:mx-auto my-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex items-center justify-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: counselling,
                                        alt: "service"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "px-5 text-[16px] mt-2",
                                    children: "Our online college platform, enables you to engage with your college admissions coach and the latest admissions data for colleges nationwide"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const service_InnovativeCounselling = (InnovativeCounselling);


/***/ }),

/***/ 4463:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






swiper__WEBPACK_IMPORTED_MODULE_3__["default"].use([
    swiper__WEBPACK_IMPORTED_MODULE_3__.Pagination,
    swiper__WEBPACK_IMPORTED_MODULE_3__.Autoplay
]);
const KeyToSuccess = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "xl:max-w-screen-xl mx-auto py-12 px-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "lg:text-3xl font-semibold text-2xl",
                children: "Standing Out is the Key to Success"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " grid grid-cols-1 lg:grid-cols-2 md:space-x-12 md:mt-16 mt-8",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "my-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-xl lg:text-2xl font-semibold ",
                                        children: "Challenges faced by High School Students"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-base",
                                        children: "At elite institutes, admission officers are not just looking for good grades and test scores. What truly matters is how you stand out and that is a major challenge that students face in the admission process. Admission officers look for students who can contribute to the institute and the cohort itself."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-xl lg:text-2xl font-semibold",
                                        children: "How Rocketship Education Students Succeed"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-base",
                                        children: "Rocketship Education helps Bangladeshi students develop a college application that will help them get noticed. Through our personalized counselling and college essay writing, we assist students position themselves as unique and strong applicants to top institutes."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                            slidesPerView: 1,
                            spaceBetween: 30,
                            loop: true,
                            autoplay: {
                                delay: 5000
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-3/4 mx-auto",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "bg-gray-700 text-white rounded-xl",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-lg p-5 ",
                                                children: "“ At elite institutes, admission officers are not just looking for good grades and test scores. What truly matters is how you stand out and that is a major challenge that students face in the admission process. Admission officers look for students who can contribute to the institute and the cohort itself. ”"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-center my-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-lg font-semibold",
                                                    children: "Alex Ferguson"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-base",
                                                    children: "VC of university"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (KeyToSuccess);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 500:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3877);
/* harmony import */ var _common_Loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8652);
/* harmony import */ var _public_gallery_feedback_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1532);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










swiper__WEBPACK_IMPORTED_MODULE_5__["default"].use([
    swiper__WEBPACK_IMPORTED_MODULE_5__.Pagination,
    swiper__WEBPACK_IMPORTED_MODULE_5__.Autoplay
]);
const StudentsTestimonials = ({ data  })=>{
    if (!data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Loader__WEBPACK_IMPORTED_MODULE_6__/* .Loader */ .a, {});
    const tmp = data;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        className: "bg-[#211A55] px-10 mt-10",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "xl:max-w-screen-xl mx-auto md:py-12 lg:px-20 md:px-6 py-9 px-4",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " grid grid-cols-1 lg:grid-cols-2 md:space-x-8",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                            src: _public_gallery_feedback_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                            alt: "Img of Glass bottle",
                            className: "hidden md:block",
                            width: 900,
                            height: 700
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "font-semibold text-xl lg:text-2xl text-white text-center mb-5",
                                children: "What happy students and parents say about us"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
                                    slidesPerView: 1,
                                    spaceBetween: 30,
                                    loop: true,
                                    autoplay: {
                                        delay: 5000
                                    },
                                    children: tmp.map((item)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-full flex flex-col mx-auto my-2 bg-white rounded-tl-3xl rounded-br-3xl",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm text-gray-700 m-5",
                                                        children: item.description
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "text-lg text-[#221a55] font-bold mx-5 mb-2",
                                                        children: item.title
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm text-gray-700 mx-5 mb-5",
                                                        children: item.designation
                                                    })
                                                ]
                                            })
                                        }, item.testimonialId);
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                href: "/contactus",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "px-10 py-3 text-[#211A56] bg-white border-2 border-[#F11B25] mr-4 rounded-tl-3xl rounded-br-3xl hover:shadow-red-500 hover:shadow-2xl hover:bg-[#F11b25] hover:text-white my-2",
                                    children: "Contact Us"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StudentsTestimonials);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8164:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Table = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "xl:max-w-screen-xl px-5 mx-auto my-10",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 md:gap-x-16 lg:gap-x-24 gap-y-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center items-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "font-extrabold text-2xl",
                                    children: "Individualized Approach"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "mt-6 text-base text-black",
                                    children: "We help you comprehend how to be a competitive applicant and personalize our guidance to suit your needs. In fact, we help you make a unique application that helps you stand out"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "overflow-hidden bg-white drop-shadow-2xl rounded-xl",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "pb-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "w-4/5 text-lg p-5 mx-auto",
                                    children: "Our students are 2.5x more likely to be admitted to a top 50 college or university"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-5/6 text-xs text-center mx-auto rounded-tl-2xl rounded-tr-2xl overflow-hidden",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                        className: "w-full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                className: "text-white text-xs",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    className: "bg-[#0a1d36]",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "p-3",
                                                            children: "Institution"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "p-3",
                                                            children: "Location"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-white text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "The New School"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "New York, NY"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-[#F3FCF6] text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "University of Rochester"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Rochester, NY"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-white text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "New York University"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "New York, NY"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-[#F3FCF6] text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "Boston University"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Boston, MA"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-white text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "Carnegie Mellon University"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Pittsburgh, PA"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-[#F3FCF6] text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "Cardinal Stritch University"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Milwaukee, WI"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-white text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "Brandeis University"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Waltham, MA"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: " bg-[#F3FCF6] text-black",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: "Florida Institute of Technology"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-8 py-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "Melbourne, FL"
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Table);


/***/ }),

/***/ 3179:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ service_Trusted)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/icons/Quotation-Mark.png
/* harmony default export */ const Quotation_Mark = ({"src":"/_next/static/media/Quotation-Mark.65772f82.png","height":800,"width":800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAeklEQVR42jWJMQ5BQRRFj6/ELzQK0UhEJdQ2IeG9N/OmsIO/Ao3NqISdWIuKdv5kkn+Lk3vvAcIYIFaGEdaAb3wBPvct1e3iCVIbr2kK+MQeamB3vdkK0KNkyfqSzyXL39aEpXxLfeuz8FcOsL123qaZdnYAzg1D6uoBXSgen7eCMDYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/common/ProgressLine.js


const ProgressLine = ({ label , backgroundColor ="#e5e5e5" , // expected format for visual parts
visualParts =[
    {
        percentage: "0%",
        color: "white"
    }
]  })=>{
    // Starting values needed for the animation
    // Mapped by "visualParts" so it can work with multiple values dynamically
    // It's an array of percentage widths
    const [widths, setWidths] = (0,external_react_.useState)(visualParts.map(()=>{
        return 0;
    }));
    (0,external_react_.useEffect)(()=>{
        // https://developer.mozilla.org/en-US/docs/Web/API/window/requestAnimationFrame
        // You need to wrap it to trigger the animation
        requestAnimationFrame(()=>{
            // Set a new array of percentage widths based on the props
            setWidths(visualParts.map((item)=>{
                return item.percentage;
            }));
        });
    }, [
        visualParts
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "progressLabel",
                children: label
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "progressVisualFull",
                // to change the background color dynamically
                style: {
                    backgroundColor
                },
                children: visualParts.map((item, index)=>{
                    // map each part into separate div and each will be animated
                    // because of the "transition: width 2s;" css in class "progressVisualPart"
                    // and because of the new width ("widths[index]", previous one was 0)
                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            width: widths[index],
                            // setting the actual color of bar part
                            backgroundColor: item.color
                        },
                        className: "progressVisualPart"
                    }, index);
                })
            })
        ]
    });
};
/* harmony default export */ const common_ProgressLine = (ProgressLine);

;// CONCATENATED MODULE: ./components/client/service/Trusted.js





const Trusted = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "py-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-[24px] text-[#211A56] font-semibold lg:text-[36px] text-center px-5",
                children: "Preferred by Students and Families"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "max-w-6xl mx-auto mt-10 mb-5 px-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 md:gap-x-16 lg:gap-x-24 gap-y-10",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex justify-center items-center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-2xl font-medium text-[#211A56]",
                                        children: "Proven Counselling"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "my-2 text-base text-black",
                                        children: "Our coaches build your confidence so that students can successfully navigate the admission process. Not to mention, our sophisticated end-to-end curriculum benefits you and helps you get admission into the institute you prefer."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "overflow-hidden bg-white drop-shadow-2xl rounded-2xl",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "p-8 lg:px-12 lg:py-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-semibold text-black",
                                        children: "How students describe their experience with RocketShip"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "my-4 text-sm text-gray-600",
                                        children: "Working with my college admissions coach has made me confident about navigating the college admissions process."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "my-2 overflow-hidden",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(common_ProgressLine, {
                                            visualParts: [
                                                {
                                                    percentage: "100%",
                                                    color: "#5A4EB2"
                                                }
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "max-w-6xl mx-auto mt-10 mb-5 px-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 md:gap-x-16 lg:gap-x-24 gap-y-10",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex bg-white flex-col h-full py-10 px-5 rounded-3xl drop-shadow-2xl justify-evenly",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "py-2 w-14",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: Quotation_Mark,
                                            alt: "counseling"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "my-2 text-sm",
                                        children: "It was your help that got him in! His essays came out amazing! The whole process is so confusing but RocketShip took all the stress out of it. You guys are amazing!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-[#211A56] font-semibold text-xl ",
                                        children: "Hamida Akter"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "my-2",
                                        children: "son admitted to University of Chicago"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex justify-center items-center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-2xl font-medium text-[#211A56]",
                                        children: "Peace of Mind"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "my-2 text-base text-black",
                                        children: "We offer consistent support to Bangladeshi students from college list development to extracurricular planning in every critical and complex step. Our approach is aimed at empowering students to learn and grow practically and academically."
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const service_Trusted = (Trusted);


/***/ }),

/***/ 2502:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_Apply__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7628);
/* harmony import */ var _components_client_service_Faqs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6866);
/* harmony import */ var _components_client_service_HeroService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7867);
/* harmony import */ var _components_client_service_KeyToSuccess__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4463);
/* harmony import */ var _components_client_service_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8164);
/* harmony import */ var _components_client_service_Trusted__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3179);
/* harmony import */ var _components_client_service_InnovativeCounselling__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7059);
/* harmony import */ var _components_client_service_CollegeGuidance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1391);
/* harmony import */ var _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2758);
/* harmony import */ var _components_MetaComponents__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3987);
/* harmony import */ var _components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3524);
/* harmony import */ var _components_client_service_StudentsTestimonials__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(500);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_Apply__WEBPACK_IMPORTED_MODULE_2__, _components_client_service_KeyToSuccess__WEBPACK_IMPORTED_MODULE_5__, _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_10__, _components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_12__, _components_client_service_StudentsTestimonials__WEBPACK_IMPORTED_MODULE_13__]);
([_components_common_Apply__WEBPACK_IMPORTED_MODULE_2__, _components_client_service_KeyToSuccess__WEBPACK_IMPORTED_MODULE_5__, _components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_10__, _components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_12__, _components_client_service_StudentsTestimonials__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














async function getStaticProps() {
    const res = await fetch(`${process.env.BASE_URL}/api/service/serviceView`);
    const data = await res.json();
    return {
        props: {
            data
        }
    };
}
// export async function getServerSideProps() {
//   const res = await fetch(`https://rocketshipedu.com/api/service/serviceView`);
//   const data = await res.json();
//   return { props: { data } };
// }
const OurService = ({ data  })=>{
    const { hero , seo , testimonial , institution , blogs  } = data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: "relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MetaComponents__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                title: seo.title,
                keywords: seo.keywords,
                description: seo.description,
                imageUrl: seo.image,
                appId: seo.facebookApp
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_HeroService__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                data: hero
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_CollegeGuidance__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_Institutions__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                data: institution
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_InnovativeCounselling__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_Trusted__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_Table__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_StudentsTestimonials__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                data: testimonial
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_KeyToSuccess__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_Apply__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_service_Faqs__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_client_home_BlogsSection__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                data: blogs
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OurService);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@emailjs/browser");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 8176:
/***/ ((module) => {

module.exports = require("react-spinners");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,3121,5675,676,1664,3221,8244,7222,1519,7628,3987,2758,3524], () => (__webpack_exec__(2502)));
module.exports = __webpack_exports__;

})();