"use strict";
exports.id = 2880;
exports.ids = [2880];
exports.modules = {

/***/ 2880:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BZ": () => (/* binding */ getTestimonials),
/* harmony export */   "fN": () => (/* binding */ updateTestimonial),
/* harmony export */   "i6": () => (/* binding */ createTestimonial),
/* harmony export */   "ps": () => (/* binding */ deleteTestimonialId),
/* harmony export */   "zm": () => (/* binding */ getTestimonialById)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const getTestimonials = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM `testimonial`");
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getTestimonialById = async (testimonialId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM testimonial WHERE testimonialId = ?", [
            testimonialId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const createTestimonial = async (title, description, designation, img)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("INSERT INTO testimonial ( title, description, designation, img) VALUES (?,?,?,?)", [
            title,
            description,
            designation,
            img
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateTestimonial = async (testimonialId, updateTitle, updateDescription, updateDesignation, updateImg)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE testimonial SET title = ?, description= ?, designation = ?, img=? WHERE testimonialId = ?", [
            updateTitle,
            updateDescription,
            updateDesignation,
            updateImg,
            testimonialId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteTestimonialId = async (testimonialId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("DELETE FROM testimonial WHERE testimonialId = ? ", [
            testimonialId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
 // const testimonials = {
 //   getTestimonials,
 //   getTestimonialById,
 //   createTestimonial,
 //   updateTestimonial,
 //   deleteTestimonialId,
 // };
 // module.exports = testimonials;


/***/ })

};
;