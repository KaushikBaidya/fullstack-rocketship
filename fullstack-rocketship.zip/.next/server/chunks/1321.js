"use strict";
exports.id = 1321;
exports.ids = [1321];
exports.modules = {

/***/ 1321:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GQ": () => (/* binding */ deleteInstitutionId),
/* harmony export */   "Lt": () => (/* binding */ createInstitution),
/* harmony export */   "TK": () => (/* binding */ updateInstitution),
/* harmony export */   "fn": () => (/* binding */ getInstitution),
/* harmony export */   "tN": () => (/* binding */ getInstitutionById)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const getInstitution = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM `institution`");
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getInstitutionById = async (institutionId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM institution WHERE institutionId = ?", [
            institutionId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const createInstitution = async (name, image)=>{
    try {
        console.log(name);
        console.log(image);
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("INSERT INTO institution ( name, image) VALUES (?,?)", [
            name,
            image
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateInstitution = async (institutionId, updateName, updateImage)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE institution SET title = ?, img= ? WHERE institutionId = ?", [
            updateName,
            updateImage,
            institutionId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteInstitutionId = async (institutionId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("DELETE FROM institution WHERE institutionId = ?", [
            institutionId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
 // const institution = {
 //   getInstitution,
 //   getInstitutionById,
 //   createInstitution,
 //   updateInstitution,
 //   deleteInstitutionId,
 // };
 // module.exports = institution;


/***/ })

};
;