"use strict";
exports.id = 2955;
exports.ids = [2955];
exports.modules = {

/***/ 2955:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$Y": () => (/* binding */ getBlogPermalink),
/* harmony export */   "VN": () => (/* binding */ publishBlog),
/* harmony export */   "Vh": () => (/* binding */ createBlog),
/* harmony export */   "_Z": () => (/* binding */ getBlogs),
/* harmony export */   "k3": () => (/* binding */ getBlogsPublished),
/* harmony export */   "o1": () => (/* binding */ deleteBlogById),
/* harmony export */   "yr": () => (/* binding */ unpublishBlog),
/* harmony export */   "zZ": () => (/* binding */ updateBlog),
/* harmony export */   "zv": () => (/* binding */ getBlogById)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const createBlog = async (title, description, permalink, keywords, seoDescription, img)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("INSERT INTO blog ( title, description, permalink, keywords, seoDescription, img, date, isPublished) VALUES (?,?,?,?,?,?, CURDATE(), 0)", [
            title,
            description,
            permalink,
            keywords,
            seoDescription,
            img
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateBlog = async (blogId, updateTitle, updateDescription, updatePermalink, updateKeywords, updateSeoDescription, updateImg)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE blog SET title = ? , description= ?, permalink = ?, keywords = ? , seoDescription = ?, img= ? WHERE blogId = ?", [
            updateTitle,
            updateDescription,
            updatePermalink,
            updateKeywords,
            updateSeoDescription,
            updateImg,
            blogId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getBlogs = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT title, blogId, isPublished FROM `blog`");
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getBlogById = async (blogId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM blog WHERE blogId = ?", [
            blogId
        ]);
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const getBlogPermalink = async (permalink)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM blog WHERE permalink = ?", [
            permalink
        ]);
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const getBlogsPublished = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query(`SELECT blogId, title, permalink, img FROM blog WHERE isPublished = '1'`);
        // connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const publishBlog = async (blogId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE blog SET isPublished = '1' WHERE blogId = ?", [
            blogId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const unpublishBlog = async (blogId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query(`UPDATE blog SET isPublished = '0' WHERE blogId =?`, [
            blogId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteBlogById = async (blogId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("DELETE FROM blog WHERE blogId = ?", [
            blogId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
 // const blogs = {
 //   getBlogs,
 //   getBlogById,
 //   getBlogPermalink,
 //   createBlog,
 //   updateBlog,
 //   publishBlog,
 //   unpublishBlog,
 //   getBlogsPublished,
 //   deleteBlogById,
 // };
 // module.exports = blogs;


/***/ })

};
;