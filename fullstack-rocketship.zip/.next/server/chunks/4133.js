"use strict";
exports.id = 4133;
exports.ids = [4133];
exports.modules = {

/***/ 4133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Bu": () => (/* binding */ ListHeader),
/* harmony export */   "Ts": () => (/* binding */ ListCol)
/* harmony export */ });
/* unused harmony export ListColDetails */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ListHeader = ({ label , className ="flex justify-start"  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "font-semibold text-center",
            children: label
        })
    });
};
const ListCol = ({ label , value , className =""  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: className,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "inline-block md:hidden font-semibold",
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "break-words",
                children: value
            })
        ]
    });
};
const ListColDetails = ({ label , value , className =""  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: className,
        children: [
            /*#__PURE__*/ _jsx("span", {
                className: "inline-block font-semibold",
                children: label
            }),
            /*#__PURE__*/ _jsx("span", {
                className: "break-words",
                children: value
            })
        ]
    });
};


/***/ })

};
;