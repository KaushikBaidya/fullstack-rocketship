"use strict";
exports.id = 8914;
exports.ids = [8914];
exports.modules = {

/***/ 8914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ updateAboutSeo),
/* harmony export */   "q": () => (/* binding */ getAboutSeo)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const getAboutSeo = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query(`SELECT * FROM about_seo`);
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const updateAboutSeo = async (updateTitle, updateDescription, updateKeywords, updatefacebook, updateImage)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE about_seo SET title = ?, description= ?, keywords = ?, facebookApp = ?, image = ? WHERE seoId  = '1'", [
            updateTitle,
            updateDescription,
            updateKeywords,
            updatefacebook,
            updateImage
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};



/***/ })

};
;