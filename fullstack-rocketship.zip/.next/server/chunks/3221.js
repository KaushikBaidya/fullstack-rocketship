"use strict";
exports.id = 3221;
exports.ids = [3221];
exports.modules = {

/***/ 9056:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "w": () => (/* binding */ AppProvider),
  "b": () => (/* binding */ useGlobalContext)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "universal-cookie"
var external_universal_cookie_ = __webpack_require__(6153);
var external_universal_cookie_default = /*#__PURE__*/__webpack_require__.n(external_universal_cookie_);
;// CONCATENATED MODULE: ./context/useData.js


const useData = ()=>{
    const cookie = new (external_universal_cookie_default())();
    const [user, setUser] = (0,external_react_.useState)(null);
    const [token, setToken] = (0,external_react_.useState)(null);
    const signOut = ()=>{
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        cookie.remove("token");
        setUser(null);
        setToken(null);
    };
    return {
        user,
        setUser,
        token,
        setToken,
        signOut
    };
};
/* harmony default export */ const context_useData = (useData);

;// CONCATENATED MODULE: ./context/context.js



const AppContext = /*#__PURE__*/ (0,external_react_.createContext)(null);
const AppProvider = ({ children  })=>{
    const data = context_useData();
    return /*#__PURE__*/ jsx_runtime_.jsx(AppContext.Provider, {
        value: data,
        children: children
    });
};
const useGlobalContext = ()=>{
    return (0,external_react_.useContext)(AppContext);
};



/***/ }),

/***/ 1510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ request)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const client = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/api"
});
const request = async ({ ...options })=>{
    const res = await client(options);
    return res;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3221:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ag": () => (/* binding */ useDeleteData),
/* harmony export */   "KQ": () => (/* binding */ useGetData),
/* harmony export */   "gU": () => (/* binding */ usePutData),
/* harmony export */   "u5": () => (/* binding */ usePostData)
/* harmony export */ });
/* harmony import */ var _helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1510);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__]);
_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const usePostData = ()=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(({ path , formData  })=>(0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "POST",
            url: path,
            data: formData,
            headers: {
                Authorization: "Bearer " + value.token
            }
        }));
};
const usePutData = ()=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(({ path , formData  })=>(0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "PUT",
            url: path,
            data: formData,
            headers: {
                Authorization: "Bearer " + value.token
            }
        }));
};
const useGetData = (key, path)=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    const { status , data , error , isLoading , isError , refetch  } = (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        key,
        {
            path: path
        }
    ], ({ queryKey , signal  })=>{
        const { path , headers  } = queryKey[1];
        return (0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "GET",
            url: path,
            // headers: headers,
            signal
        });
    });
    return {
        status,
        data,
        error,
        isLoading,
        isError,
        refetch
    };
};
const useDeleteData = ()=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(({ path  })=>(0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "DELETE",
            url: path,
            headers: {
                Authorization: "Bearer " + value.token
            }
        }));
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;