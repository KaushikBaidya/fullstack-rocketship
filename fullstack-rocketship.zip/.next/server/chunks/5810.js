"use strict";
exports.id = 5810;
exports.ids = [5810];
exports.modules = {

/***/ 5810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Oo": () => (/* binding */ createConsult),
/* harmony export */   "ZL": () => (/* binding */ getConsults),
/* harmony export */   "ZS": () => (/* binding */ getConsultById)
/* harmony export */ });
/* unused harmony export deleteConsultById */
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const getConsults = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT firstname, lastname, consultdate, consulttime, consultId FROM `consult` ORDER BY consultId DESC");
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getConsultById = async (consultId)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("SELECT * FROM consult WHERE consultId = ?", [
            consultId
        ]);
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const createConsult = async (firstname, lastname, email, phone, consultdate, consulttime, details)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("INSERT INTO consult ( firstname, lastname, email, phone, consultdate, consulttime, details) VALUES (?,?,?,?,?,?,?)", [
            firstname,
            lastname,
            email,
            phone,
            consultdate,
            consulttime,
            details
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteConsultById = async (consultId)=>{
    try {
        const connection = await mysql.createConnection(mysqlConfig);
        const [rows] = await connection.query("DELETE FROM consult WHERE consultId = ?", [
            consultId
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};



/***/ })

};
;