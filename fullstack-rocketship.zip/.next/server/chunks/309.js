"use strict";
exports.id = 309;
exports.ids = [309];
exports.modules = {

/***/ 4165:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CKeditor)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function CKeditor({ onChange , editorLoaded , name , value  }) {
    const editorRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { CKEditor , ClassicEditor  } = editorRef.current || {};
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        editorRef.current = {
            CKEditor: (__webpack_require__(384).CKEditor),
            ClassicEditor: __webpack_require__(5614)
        };
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: editorLoaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CKEditor, {
            name: name,
            editor: ClassicEditor,
            data: value,
            onChange: (event, editor)=>{
                const data = editor.getData();
                onChange(data);
            }
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Editor loading"
        })
    });
} // import React from "react";
 // import CKEditor from "@ckeditor/ckeditor5-react";
 // import DecoupledEditor from "@ckeditor/ckeditor5-build-decoupled-document";
 // export default function CKeditor() {
 //   return (
 //     <div>
 //       <CKEditor
 //         editor={DecoupledEditor}
 //         onInit={(editor) => {
 //           editor.ui
 //             .getEditableElement()
 //             .parentElement.insertBefore(
 //               editor.ui.view.toolbar.element,
 //               editor.ui.getEditableElement()
 //             );
 //         }}
 //         onChange={(event, editor) => {
 //           const tmp = editor.getData();
 //           this.setState({ text: data });
 //         }}
 //       />
 //     </div>
 //   );
 // }


/***/ }),

/***/ 5793:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4981);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _CKeditor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4165);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





// import CKEditor from "@ckeditor/ckeditor5-react";
const TextEditor = ({ control , name , label , errorMessage =""  })=>{
    const [editorLoaded, setEditorLoaded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setEditorLoaded(true);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
                control: control,
                name: name,
                rules: {
                    required: "Description is required"
                },
                render: ({ field  })=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CKeditor__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            name: "description",
                            onChange: (data)=>{
                                setData(data);
                            },
                            ...field,
                            editorLoaded: editorLoaded
                        })
                    });
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-11",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    message: errorMessage
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextEditor);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 309:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1908);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6201);
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7222);
/* harmony import */ var _common_button_SaveButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4284);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _InputFile__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2059);
/* harmony import */ var _TextEditor__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5793);
/* harmony import */ var _common_button_DraftButton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6772);
/* harmony import */ var _TextArea__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1519);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__, _TextEditor__WEBPACK_IMPORTED_MODULE_11__, _TextArea__WEBPACK_IMPORTED_MODULE_13__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__, _TextEditor__WEBPACK_IMPORTED_MODULE_11__, _TextArea__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











// import InputFile from "../InputFile";
// import RichText from "../RichText";



const schema = yup__WEBPACK_IMPORTED_MODULE_3__.object({
    blogId: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    title: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.").max(1000),
    description: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required."),
    keywords: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.").max(1000),
    seoDescription: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.").max(4000),
    permalink: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(100)
}).shape({
    filepath: yup__WEBPACK_IMPORTED_MODULE_3__.mixed()
});
const BlogsForm = ({ defaultValues , path , mutateAsync , btnText  })=>{
    const [imageUrl, setPhoto] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(defaultValues.img);
    const [submitting, setSubmitting] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { register , handleSubmit , reset , control , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
        defaultValues: defaultValues,
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__.yupResolver)(schema)
    });
    const { title , description , filepath , keywords , seoDescription , permalink  } = errors;
    const onSubmit = async (formData)=>{
        if (imageUrl === "") {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.error("Upload not complete! Please wait.");
            return;
        }
        setSubmitting(true);
        let data = {
            blogId: formData.blogId,
            title: formData.title,
            description: formData.description,
            permalink: formData.permalink !== "" ? formData.permalink.replace(/\s/g, "-") : formData.title.replace(/\s/g, "-"),
            keywords: formData.keywords,
            seoDescription: formData.seoDescription,
            img: imageUrl
        };
        try {
            const { status  } = await mutateAsync({
                path: path,
                formData: data
            });
            if (status === 201) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.success("Saved successfully!");
            }
            if (status === 204) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.success("Update successful!");
                router.push("/dashboard/blog");
            }
        } catch (error) {
            if (error.response) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.error("Response : " + error.response.data);
            } else if (error.request) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.error("Request : " + error.message);
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.error("Error :", error.message);
            }
        } finally{
            reset();
            setPhoto("");
            setSubmitting(false);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "hidden",
                ...register("blogId")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "form-col",
                children: [
                    imageUrl?.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: imageUrl,
                        alt: "PHOTO",
                        width: 200,
                        height: 100
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputFile__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        name: "filepath",
                        label: "Upload Feature Image. Image resolution must be (381px X 200px)",
                        accept: "image/*",
                        register: register,
                        action: setPhoto,
                        errorMessage: filepath?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "title",
                        label: "Blog Title",
                        type: "text",
                        register: register,
                        errorMessage: title?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "keywords",
                        label: "SEO Keywords",
                        type: "text",
                        register: register,
                        errorMessage: keywords?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "seoDescription",
                        label: "SEO Short Description",
                        type: "text",
                        register: register,
                        errorMessage: seoDescription?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "permalink",
                        label: "Url Name",
                        type: "text",
                        register: register,
                        errorMessage: permalink?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TextEditor__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        control: control,
                        name: "description",
                        label: "Blog Description",
                        errorMessage: description?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_button_SaveButton__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        btnText: btnText,
                        disabled: submitting
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogsForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6772:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const DraftButton = ({ btnText , disabled , isRow =true  })=>{
    return /*#__PURE__*/ _jsx("div", {
        className: isRow ? "form-row w-full" : "md:mt-6",
        children: /*#__PURE__*/ _jsx("button", {
            type: "submit",
            className: "draft-btn",
            disabled: disabled,
            children: btnText
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (DraftButton)));


/***/ })

};
;