"use strict";
exports.id = 1246;
exports.ids = [1246];
exports.modules = {

/***/ 1246:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1908);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7222);
/* harmony import */ var _common_button_SaveButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4284);
/* harmony import */ var _TextArea__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1519);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _InputFile__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2059);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _TextArea__WEBPACK_IMPORTED_MODULE_9__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _TextArea__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const schema = yup__WEBPACK_IMPORTED_MODULE_3__.object({
    heroId: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    title: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required."),
    subtitle: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.")
}).shape({
    filepath: yup__WEBPACK_IMPORTED_MODULE_3__.mixed()
});
const HeroForm = ({ defaultValues , path , mutateAsync , action , btnText , returnPath  })=>{
    const [imageUrl, setPhoto] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(defaultValues.image);
    const [submitting, setSubmitting] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { register , handleSubmit , reset , control , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
        defaultValues: defaultValues,
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__.yupResolver)(schema)
    });
    const { title , subtitle , filepath  } = errors;
    const onSubmit = async (formData)=>{
        if (imageUrl === "") {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Upload not complete! Please wait.");
            return;
        }
        setSubmitting(true);
        let data = {
            heroId: formData.heroId,
            title: formData.title,
            subtitle: formData.subtitle,
            image: imageUrl
        };
        try {
            const { status  } = await mutateAsync({
                path: path,
                formData: data
            });
            if (status === 201) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Saved successfully!");
                reset();
            }
            if (status === 204) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Update successful!");
                router.push(returnPath);
            }
        } catch (error) {
            if (error.response) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Response : " + error.response.data);
            } else if (error.request) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Request : " + error.message);
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Error :", error.message);
            }
        } finally{
            setPhoto("");
            setSubmitting(false);
            action();
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        onSubmit: handleSubmit(onSubmit),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "form-col",
            children: [
                imageUrl?.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_10___default()), {
                    src: imageUrl,
                    alt: "PHOTO",
                    width: 200,
                    height: 200
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputFile__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    name: "filepath",
                    label: "Upload Image. Image resolution must be (425px X 425 px)",
                    accept: "image/*",
                    register: register,
                    action: setPhoto,
                    errorMessage: filepath?.message
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    name: "title",
                    label: "Title",
                    type: "text",
                    register: register,
                    errorMessage: title?.message
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TextArea__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    control: control,
                    name: "subtitle",
                    label: "Subtitle",
                    errorMessage: subtitle?.message
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_button_SaveButton__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    btnText: btnText,
                    disabled: submitting
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;