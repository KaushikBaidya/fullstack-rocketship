"use strict";
exports.id = 1706;
exports.ids = [1706];
exports.modules = {

/***/ 1706:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ getServiceHero),
/* harmony export */   "j": () => (/* binding */ updateServiceHero)
/* harmony export */ });
/* harmony import */ var _database_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1902);
const mysql = __webpack_require__(2418);

const getServiceHero = async ()=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query(`SELECT * FROM service_hero`);
        connection.end(console.log("connection ended"));
        return rows[0];
    } catch (e) {
        console.error(e);
    }
};
const updateServiceHero = async (updatedTitle, updatedSubtitle, updateImage)=>{
    try {
        const connection = await mysql.createConnection(_database_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
        const [rows] = await connection.query("UPDATE service_hero SET title = ?, subtitle = ?, image = ? WHERE heroId = 1", [
            updatedTitle,
            updatedSubtitle,
            updateImage
        ]);
        connection.end(console.log("connection ended"));
        return rows;
    } catch (e) {
        console.error(e);
    }
};
 // const servicehero = {
 //   getServiceHero,
 //   updateServiceHero,
 // };
 // module.exports = servicehero;


/***/ })

};
;