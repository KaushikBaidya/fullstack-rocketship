"use strict";
exports.id = 7628;
exports.ids = [7628];
exports.modules = {

/***/ 2282:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/violet.cae5fac9.png","height":130,"width":130,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0klEQVR42mMAgTCzjcwMuEBn6itGEF0Z/dgww293vbfRnForodl+QCEWuCIf/RVeMT5Ln7klN//3TKv/7+sy+7WTwiI3qHSGRJjtsp2T86e8ubE47dv9FSnfg+1Xvkj03LcYqqCMP8l16Y5JhXOene3O+nixL/Uzv/ymayWRJ87NafqpCFaS6Xu8zdlp3k+XoMw/7sEF//085v6sjL3W9f//fyawgkkV73QqE8/vjHbffjTAes3OENtVGXAHNqbfBftiy7T/3JOLXwshu74+7SYjAB6nVlnKbJXjAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7628:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_icons_violet_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2282);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5641);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1908);
/* harmony import */ var _SelectList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3239);
/* harmony import */ var _admin_Input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7222);
/* harmony import */ var _admin_TextArea__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1519);
/* harmony import */ var _button_SaveButton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4284);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__, _admin_TextArea__WEBPACK_IMPORTED_MODULE_11__]);
([react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__, _admin_TextArea__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






// import SaveButton from "../../common/button/SaveButton";







const schema = yup__WEBPACK_IMPORTED_MODULE_7__.object({
    first_name: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required.").max(50),
    last_name: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required.").max(50),
    user_email: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required.").max(50),
    phone_number: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required.").max(50),
    user_identity: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required"),
    user_year: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required"),
    social_media: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required."),
    description: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("Required.")
});
const Contact = ({ defaultValues , path , mutateAsync  })=>{
    const [submitting, setSubmitting] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { register , handleSubmit , reset , control , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm)({
        defaultValues: defaultValues,
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__.yupResolver)(schema)
    });
    const { first_name , last_name , user_email , phone_number , user_identity , user_year , social_media , description  } = errors;
    const onSubmit = async (formData)=>{
        setSubmitting(true);
        const data = {
            first_name: formData.first_name,
            last_name: formData.last_name,
            user_email: formData.user_email,
            phone_number: formData.phone_number,
            user_identity: formData.user_identity,
            user_year: formData.user_year,
            social_media: formData.social_media,
            description: formData.description
        };
        try {
            _emailjs_browser__WEBPACK_IMPORTED_MODULE_3___default().send(`${"service_tixso7v"}`, `${"template_5h2gpjt"}`, data, `${"h0ZwxjZ7EmXBFPVDU"}`).then(()=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__["default"].success("Message sent successfully");
            }, (error)=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__["default"].error("Response : " + error);
            });
        } catch (error) {
            if (error.response) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__["default"].error("Response : " + error.response.data);
            } else if (error.request) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__["default"].error("Request : " + error.message);
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__["default"].error("Error : ", error.message);
            }
        } finally{
            reset();
            setSubmitting(false);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "xl:max-w-screen-xl px-4 mx-auto sm:px-6 lg:px-8 lg:py-10",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 md:gap-x-16 lg:gap-x-24 gap-y-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center items-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-24 h-24 mx-auto",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: _public_icons_violet_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                        alt: "graduate"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "mt-6 text-2xl font-bold leading-relaxed text-black",
                                    children: "Contact a Rocketship Consultant and start your journey for United States."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "mt-6 text-base text-black",
                                    children: "We help Bangladeshi students go through the college admissions process by offering them a personalized and detailed admissions guidance program that empowers students to achieve success."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "mt-6 text-base font-medium text-black my-4",
                                    children: "During our initial consultation, we will:"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "list-disc px-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Assess your student’s applicant profile and higher education goals"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Provide detailed information about our services and programming"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: "Share tips on how to navigate the U.S. college admissions process"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-2xl text-[#4e2ddf] mt-4",
                                    children: "Lets Get Started !"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full p-10 bg-white drop-shadow-2xl rounded-tl-3xl rounded-br-3xl",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                onSubmit: handleSubmit(onSubmit),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-col",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_Input__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            name: "first_name",
                                            label: "First Name",
                                            type: "text",
                                            register: register,
                                            errorMessage: first_name?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_Input__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            name: "last_name",
                                            label: "Last Name",
                                            type: "text",
                                            register: register,
                                            errorMessage: last_name?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_Input__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            name: "user_email",
                                            label: "Email",
                                            type: "text",
                                            register: register,
                                            errorMessage: user_email?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_Input__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            name: "phone_number",
                                            label: "Phone",
                                            type: "text",
                                            register: register,
                                            errorMessage: phone_number?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SelectList__WEBPACK_IMPORTED_MODULE_9__/* .SelectFromOptions */ .p, {
                                            register: register,
                                            options: [
                                                "Student",
                                                "Parent",
                                                "Guardian",
                                                "School Administrator/Counselor",
                                                "Employer",
                                                "Other"
                                            ],
                                            label: "I am a...",
                                            name: "user_identity",
                                            errorMessage: user_identity?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SelectList__WEBPACK_IMPORTED_MODULE_9__/* .SelectFromOptions */ .p, {
                                            register: register,
                                            options: [
                                                "2023",
                                                "2024",
                                                "2025",
                                                "2026",
                                                "Gap Year",
                                                "Transfer"
                                            ],
                                            label: "Expected Graduation Year",
                                            name: "user_year",
                                            errorMessage: user_year?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SelectList__WEBPACK_IMPORTED_MODULE_9__/* .SelectFromOptions */ .p, {
                                            register: register,
                                            options: [
                                                "Instagram",
                                                "Twitter",
                                                "Reddit",
                                                "Facebook",
                                                "LinkedIn",
                                                "Other"
                                            ],
                                            label: "How did you hear about us?",
                                            name: "social_media",
                                            errorMessage: social_media?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_TextArea__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                            control: control,
                                            name: "description",
                                            label: "If you have anything to say...",
                                            errorMessage: description?.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_SaveButton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                            btnText: "Submit",
                                            disabled: submitting
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3239:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ SelectFromOptions)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _admin_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4981);



// import ErrorMessage from "./Error/ErrorMessage";
const SelectFromOptions = ({ register , options , label , name , errorMessage , ...rest })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: label
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                className: "form-control bg-white",
                ...register(name),
                ...rest,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: "",
                        children: "-- Select --"
                    }),
                    options.map((value)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: value,
                            children: value
                        }, value))
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                message: errorMessage
            })
        ]
    });
};


/***/ }),

/***/ 4284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const SaveButton = ({ btnText , disabled , isRow =true  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: isRow ? "form-row w-full" : "md:mt-6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            type: "submit",
            className: "save-btn",
            disabled: disabled,
            children: btnText
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SaveButton);


/***/ })

};
;